'use strict';
/* ================= 工具函数 ================= */
var pad = function(n){ return String(n).padStart(2,'0'); };
var fmt  = function(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); };
var parse = function(s){ var p=s.split('-'); return new Date(+p[0], +p[1]-1, +p[2]); };
var addDays = function(d,n){ var x=new Date(d); x.setDate(x.getDate()+n); return x; };
/* 安全按月平移日期：自动夹紧目标月最大天数（如 1/31 +1月 -> 2/28） */
function addMonthsSafe(dateStr, deltaMonths){
  var d = parse(dateStr);
  var y = d.getFullYear(), m = d.getMonth() + deltaMonths, day = d.getDate();
  var target = new Date(y, m, 1);
  var maxDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  target.setDate(Math.min(day, maxDay));
  return fmt(target);
}
var weekStart = function(d){ var x=new Date(d); x.setDate(x.getDate()-((x.getDay()+6)%7)); return x; }; /* 周一 */
var sameDay = function(a,b){ return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate(); };
/* ISO 8601 周次：周一为一周起点，包含当年第一个周四的周为第 1 周 */
function isoWeek(d){
  var date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  var dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  var yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
}
var WD = ['日','一','二','三','四','五','六'];
var WD_EN = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var MON_EN = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var LANG_KEY = 'projectPlanQuickEditor.lang';
var curLang = (function(){
  try{
    if(/[?&]lang=en\b/i.test(location.search)) return 'en';
    if(/[?&]lang=zh\b/i.test(location.search)) return 'zh';
    return localStorage.getItem(LANG_KEY) === 'en' ? 'en' : 'zh';
  }catch(e){ return 'zh'; }
})();
var I18N = {
  zh: {
    appTitle:'项目计划编辑器', projPh:'输入项目名称…', projTitle:'项目名称',
    plansBtn:'计划库', plansTip:'查看已保存的计划',
    saveBtn:'保存', saveTip:'将当前内容保存为一份计划快照',
    previewBtn:'预览', previewTip:'以只读画板方式预览整张计划表（可缩放/拖动，不可编辑）',
    exportBtn:'导出', moreTip:'更多操作（导入 / 示例 / 帮助 / 清空）',
    importMenu:'导入 .md 计划', sampleMenu:'载入示例计划', helpMenu:'使用帮助', clearMenu:'清空当前计划',
    addTop:'＋ 添加事项', undoBtn:'↩ 撤回', undoTip:'撤回上一步操作（行/列/节点/格式等）',
    colW_075:'列宽 · 窄', colW_1:'列宽 · 标准', colW_125:'列宽 · 宽', colW_15:'列宽 · 超宽',
    colScaleTip:'时间列宽（整轴同步缩放）',
    linkBtn:'手动连线', linkTip:'点击后依次选择两个节点图标，建立手动连线（点击连线可调整粗细/虚实）',
    lineStyleBtn:'连线样式', lineStyleTip:'调整时间轴连线颜色/粗细/虚实/箭头形状',
    resetBtn:'重置布局', resetTip:'清除所有手动拖动偏移，恢复自动布局',
    rangeTip:'设置计划起止日期', startTip:'起始日期', endTip:'结束日期',
    presetWeek:'本周', presetMonth:'本月', presetQuarter:'本季度',
    viewDay:'日', viewWeek:'周', viewMonth:'月',
    scrollLTip:'时间轴向左滑动', scrollRTip:'时间轴向右滑动', goToday:'今天', goTodayTip:'定位到今天',
    fitBtn:'显示全部', fitTip:'时间轴自动缩放至覆盖所有节点',
    extWeek:'＋1周', extWeekTip:'时间轴末尾拉长一周', extMonth:'＋1月', extMonthTip:'时间轴末尾拉长一个月',
    tabAdd:'＋ 新建计划表', tabAddTip:'新建计划表标签页',
    lgDot:'时间节点图标（可改形状/颜色/大小）', lgLine:'连接线 = 先后顺序', lgChip:'节点任务（线性展开）',
    lgHint:'⇆ 拉长时间轴 · 悬停节点点「＋」或 Shift+点击直连 · 拖行底/列缘调宽高 · 双击时间表头编辑年月',
    stretchTip:'拖动：向右拉长时间轴，向左缩短',
    emptyTable:'暂无事项，点击「＋ 添加事项」开始计划',
    emptyRow:'＋ 点击添加第一个时间节点', emptyRowRange:'当前时间范围内没有节点（可点击空白处新增）',
    addRowBtn:'＋ 添加事项', metaFmt:'{n} 个节点 · 共 {t} 个任务',
    planMetaFmt:'{i} 个事项 · {n} 个节点 · {t} 个任务', planCountFmt:'{n} 份',
    planEmpty:'暂无保存的计划，先在上方保存当前内容。',
    loadBtn:'载入', delBtn:'删除', cancelBtn:'取消', closeBtn:'关闭', applyBtn:'应用', addBtn:'添加',
    nodeAddTitle:'新增时间节点', nodeEditTitle:'编辑时间节点',
    nodeTitleLbl:'节点名称', nodeTitlePh:'如：需求评审、开发完成、正式上线',
    lblFmtTip:'标签格式', dateLbl:'日期', weekFmt:'第 {w} 周',
    nodeIconLbl:'节点图标', nodeIconTip:'（形状 / 颜色 / 大小）',
    nodeItemLbl:'所属事项', nodeTasksLbl:'具体节点任务', nodeTasksTip:'（每条任务可单独设置颜色 / 加粗 / 斜体 / 字号）',
    nodeAddTask:'＋ 添加任务', nodeDel:'删除节点', taskPh:'填写节点任务，如：输出文档',
    cellTitle:'编辑事项单元格', cellTextLbl:'文本内容', cellTextPh:'填写文本，如：产品项目A',
    textFmtLbl:'文字格式', cellMergeLbl:'合并操作', cellMergeTip:'（合并后时间轴区域保持不变）',
    mergeU:'↑ 向上合并', mergeD:'↕ 向下合并', mergeL:'← 向左合并', mergeR:'↔ 向右合并', splitBtn:'拆分',
    headTitle:'编辑列标题', headTextLbl:'标题文本', headTextPh:'如：项目、阶段、责任人',
    headMergeLbl:'左右列合并', headMergeTip:'（标题跨列显示，各列数据与时间轴不变）',
    hdMergeL:'← 向左合并', hdMergeR:'→ 向右合并',
    thSegTitle:'编辑时间分组标题 / 年月', thColTitle:'编辑时间列标题 / 年月',
    thYmLbl:'调整年月', thYmTip:'（修改后将灵活调整时间轴年月）', thYearUnit:'年', thMonthUnit:'月',
    thShiftLbl:'同步平移全部节点日期（保持相对进度不变）',
    thCustomLbl:'自定义显示标题', thCustomTip:'（可选，留空则显示默认年月）', thReset:'默认', thDefPh:'默认显示：{d}',
    itemTitle:'添加事项', itemNameLbl:'事项名称', itemNamePh:'如：需求梳理',
    exportTitle:'导出计划', exportDesc:'复制 Markdown、下载 .md，或导出为 Excel / PNG / PDF 等多种格式。',
    pngBtn:'导出 PNG 图片', pdfBtn:'导出 PDF', printBtn:'打印 / 存为 PDF', dlBtn:'下载 .md', excelBtn:'导出 Excel', copyBtn:'复制',
    helpTitle:'使用帮助 · 项目计划快速编辑器',
    lineTitle:'时间轴连线样式', lnColorLbl:'线条颜色', lnWidthLbl:'线条粗细', lnStyleLbl:'线条虚实', lnArrowLbl:'箭头形状',
    linkTitle:'手动连线样式', lkDel:'删除连线',
    plansTitle:'计划库', planSaveLbl:'保存当前计划为', planSavePh:'如：Q3 产品迭代计划',
    planSaveDesc:'保存为一份可随时载入的计划快照（同名计划将被覆盖）。', planListHead:'已保存的计划',
    importTitle:'导入计划', importWarn:'⚠️ 请务必使用本编辑器「导出」生成的 <b>.md</b> 文件导入，否则可能无法正常显示或恢复计划。',
    importFileLbl:'选择文件', importDesc:'导入成功后，将作为新的计划表标签页打开。',
    pvClose:'✕ 退出预览', pvTitleDef:'计划预览', pvTitleFmt:'{name} · 计划预览', pvFit:'适应窗口',
    tipDblHead:'双击编辑列标题（文字/格式/合并）', tipDblTime:'双击编辑时间标题或调整年月',
    tipColResize:'拖动调整该列宽度', tipRowResize:'拖动调整本行高度', tipBodyClick:'点击时间轴空白处添加时间节点',
    tipNode:'点击编辑节点 · Shift+点击或点右侧「＋」连接其他节点', tipPort:'点击连接到其他节点',
    tipDragEdit:'拖动调整位置 · 点击编辑', tipRowDrag:'拖动调整行顺序', tipRowAdd:'在下方插入一行', tipRowDel:'删除事项',
    tipColAdd:'增加一列', tipColDel:'删除该列', tipTabClose:'关闭标签页',
    tStartAfterEnd:'开始日期不能晚于结束日期', tPosMoved:'已调整位置（点「重置布局」可还原）',
    tRowReordered:'已调整行顺序', tFitAll:'时间轴已覆盖全部 {n} 个节点', tFitEmpty:'暂无节点，已恢复默认范围',
    tRowResized:'已调整行高（点「重置布局」可还原）', tLeftColResized:'已调整左侧列宽度',
    tColResized:'已调整列宽为 {w}px（点「重置布局」可还原）',
    tSelectDate:'请选择日期', tNoItem:'未找到所属事项', tNodeDeleted:'已删除节点',
    tEnterItem:'请输入事项名称', tRowInserted:'已在下方插入新行', tColAdded:'已增加一列（双击列标题可编辑文字/格式/合并）',
    tKeepOneCol:'至少保留一列', tColDeleted:'已删除一列', tHeadMergeL:'已向左合并列标题', tHeadMergeR:'已向右合并列标题',
    tHeadSplit:'已拆分列标题', tHeadSaved:'已保存列标题', tMergeD:'已向下合并', tMergeR:'已向右合并',
    tMergeU:'已向上合并', tMergeL:'已向左合并', tCellSplit:'已拆分', tCellSaved:'已保存单元格',
    tFirstRow:'已是首行，无法向上合并', tUpperMerged:'上方相邻单元格已合并', tFirstCol:'已是首列，无法向左合并', tLeftMerged:'左侧相邻单元格已合并',
    tViewSwitched:'已切换为{v}视图', tNoManualPos:'当前没有手动调整的位置', tResetDone:'已还原 {n} 项自动布局（位置/行高/列宽）',
    tColScaleDone:'时间列宽已调整（整轴同步）', tLineSaved:'已更新时间轴连线样式',
    tLinkStart:'已选择起点，点击另一个节点图标建立连线（点空白处或按 Esc 取消）',
    tLinkStartCancel:'已取消连线起点', tLinkDup:'这两个节点之间已有手动连线',
    tLinkCreated:'已建立手动连线（可调整粗细/虚实）', tLinkDeleted:'已删除手动连线', tLinkUpdated:'已更新手动连线样式',
    tLinkCancelled:'已取消连线', tLinkExit:'已退出连线模式',
    tInvalidYear:'请输入 2000–2100 之间的有效年份', tInvalidMonth:'请选择有效月份',
    tShifted:'已将时间轴{dir} {n} 个月{sync}', tDirFwd:'后移', tDirBack:'前移', tSyncNote:'（节点已同步平移）',
    tTimeLabelSaved:'已更新自定义时间标题', tTimeLabelReset:'已恢复默认时间标题',
    tNoUndo:'没有可撤回的操作', tUndone:'已撤回上一步操作',
    tNewSheet:'已新建计划表标签页', tKeepOneSheet:'至少保留一个计划表',
    tCopied:'已复制到剪贴板', tCopiedCompat:'已复制（兼容模式）', tDownloaded:'已下载 {f}',
    tExcelExported:'已导出 Excel（{f}）', tNoExport:'暂无事项可导出', tPngExported:'已导出 PNG 图片',
    tPdfExported:'已导出 PDF', tPdfFail:'PDF 生成失败', tNoPreview:'暂无事项可预览',
    tSaveFull:'保存失败：本地存储空间可能已满', tPlanSaved:'已保存计划「{name}」',
    tPlanSavedLib:'已保存计划「{name}」，可在「计划库」查看', tPlanLoaded:'已载入计划「{name}」', tPlanDeleted:'已删除计划「{name}」',
    tImportBad:'未检测到本编辑器导出的数据，请导入本工具导出的 .md 文件', tImportErr:'导入数据解析失败，文件可能已损坏或被修改',
    tImportEmpty:'导入文件缺少有效的计划数据', tImported:'已导入计划「{name}」', tReadFail:'读取文件失败',
    cDelItem:'删除事项「{name}」？其下 {n} 个节点将一并删除。',
    cCloseTab:'关闭计划表「{name}」？该表当前内容将从工作区移除（已保存到「计划库」的快照不受影响）。',
    cLoadSample:'载入示例计划？将覆盖当前数据。', cClearAll:'清空所有事项？此操作不可恢复。',
    cOverwritePlan:'已存在同名计划「{name}」，是否覆盖？', cLoadPlan:'载入计划「{name}」将覆盖当前编辑内容，是否继续？',
    cDelPlan:'删除已保存的计划「{name}」？此操作不可恢复。',
    shapes:{ circle:'● 圆形', diamond:'◇ 菱形', triangle:'△ 三角形', square:'□ 方形', star:'☆ 星形', hexagon:'⬡ 六边形' },
    lstyles:{ solid:'实线', dashed:'虚线', dotted:'点线' },
    arrows:{ triangle:'▶ 实心三角', 'triangle-open':'▷ 空心三角', chevron:'› V 形箭头', dot:'● 圆点', diamond:'◆ 菱形', none:'— 无箭头' }
  },
  en: {
    appTitle:'Project Plan Editor', projPh:'Project title…', projTitle:'Project Title',
    plansBtn:'Library', plansTip:'Browse and manage saved plan snapshots',
    saveBtn:'Save', saveTip:'Save current plan as a snapshot',
    previewBtn:'Preview', previewTip:'Open read-only zoomable preview board',
    exportBtn:'Export', moreTip:'More actions (Import / Sample / Help / Clear)',
    importMenu:'Import .md Plan', sampleMenu:'Load Sample Plan', helpMenu:'Help & Guide', clearMenu:'Clear Current Plan',
    addTop:'+ Add Item', undoBtn:'↩ Undo', undoTip:'Undo last action (rows, columns, milestones, layout)',
    colW_075:'Col · Narrow', colW_1:'Col · Normal', colW_125:'Col · Wide', colW_15:'Col · Extra',
    colScaleTip:'Uniform timeline column width',
    linkBtn:'Link', linkTip:'Select two milestones to create a manual connector',
    lineStyleBtn:'Style', lineStyleTip:'Customize timeline connector color, width, pattern & arrow',
    resetBtn:'Reset', resetTip:'Reset manual drag offsets, row heights & column widths',
    rangeTip:'Plan date range', startTip:'Start date', endTip:'End date',
    presetWeek:'Wk', presetMonth:'Mo', presetQuarter:'Qtr',
    viewDay:'Day', viewWeek:'Wk', viewMonth:'Mo',
    scrollLTip:'Scroll timeline left', scrollRTip:'Scroll timeline right', goToday:'Today', goTodayTip:'Jump to today',
    fitBtn:'Fit', fitTip:'Fit timeline range to all milestones',
    extWeek:'+1W', extWeekTip:'Extend timeline by 1 week', extMonth:'+1M', extMonthTip:'Extend timeline by 1 month',
    tabAdd:'+ New Sheet', tabAddTip:'Create a new plan tab',
    lgDot:'Milestone (shape, color & size)', lgLine:'Sequence flow', lgChip:'Task chain',
    lgHint:'Drag ⇆ to extend · Hover "+" or Shift+Click to link · Drag edges to resize · Dbl-click dates to edit',
    stretchTip:'Drag right to extend timeline, left to shorten',
    emptyTable:'No items yet. Click "+ Add Item" to get started.',
    emptyRow:'+ Click timeline to add a milestone', emptyRowRange:'No milestones in this date range (click to add)',
    addRowBtn:'+ Add Item', metaFmt:'{n} milestones · {t} tasks',
    planMetaFmt:'{i} items · {n} milestones · {t} tasks', planCountFmt:'{n} saved',
    planEmpty:'No saved plans yet. Save your current plan above.',
    loadBtn:'Load', delBtn:'Delete', cancelBtn:'Cancel', closeBtn:'Close', applyBtn:'Apply', addBtn:'Add',
    nodeAddTitle:'Add Milestone', nodeEditTitle:'Edit Milestone',
    nodeTitleLbl:'Milestone Title', nodeTitlePh:'e.g., Design Review, Code Freeze, Launch',
    lblFmtTip:'Label style', dateLbl:'Date', weekFmt:'W{w}',
    nodeIconLbl:'Milestone Icon', nodeIconTip:'(Shape / Color / Size)',
    nodeItemLbl:'Item / Lane', nodeTasksLbl:'Tasks', nodeTasksTip:'(Individual color, bold, italic & font size)',
    nodeAddTask:'+ Add Task', nodeDel:'Delete Milestone', taskPh:'Task description, e.g., Deliver spec',
    cellTitle:'Edit Item Cell', cellTextLbl:'Text', cellTextPh:'e.g., Phase 1 / Core Feature',
    textFmtLbl:'Text Style', cellMergeLbl:'Merge Cells', cellMergeTip:'(Timeline lanes remain independent)',
    mergeU:'↑ Up', mergeD:'↕ Down', mergeL:'← Left', mergeR:'↔ Right', splitBtn:'Split',
    headTitle:'Edit Column Header', headTextLbl:'Header Title', headTextPh:'e.g., Phase, Deliverable, Owner',
    headMergeLbl:'Merge Headers', headMergeTip:'(Spans across columns without changing data)',
    hdMergeL:'← Merge Left', hdMergeR:'→ Merge Right',
    thSegTitle:'Edit Timeline Group / Schedule', thColTitle:'Edit Timeline Column / Schedule',
    thYmLbl:'Shift Year / Month', thYmTip:'(Flexibly adjust timeline schedule)', thYearUnit:'Y', thMonthUnit:'',
    thShiftLbl:'Sync all milestone dates (preserve relative schedule)',
    thCustomLbl:'Custom Display Label', thCustomTip:'(Optional; leave blank for default)', thReset:'Reset', thDefPh:'Default: {d}',
    itemTitle:'Add Item', itemNameLbl:'Item Name', itemNamePh:'e.g., Requirements & Scoping',
    exportTitle:'Export Plan', exportDesc:'Copy Markdown, download .md, or export to Excel, PNG, or PDF.',
    pngBtn:'Export PNG', pdfBtn:'Export PDF', printBtn:'Print / Save PDF', dlBtn:'Download .md', excelBtn:'Export Excel', copyBtn:'Copy',
    helpTitle:'Help & User Guide · Project Plan Editor',
    lineTitle:'Timeline Connector Style', lnColorLbl:'Color', lnWidthLbl:'Stroke Width', lnStyleLbl:'Line Pattern', lnArrowLbl:'Arrowhead',
    linkTitle:'Manual Link Style', lkDel:'Delete Link',
    plansTitle:'Plan Library', planSaveLbl:'Save Current Plan As', planSavePh:'e.g., Q3 Product Roadmap',
    planSaveDesc:'Save as a reusable snapshot (same name overwrites existing).', planListHead:'Saved Plans',
    importTitle:'Import Plan', importWarn:'⚠️ Please only import <b>.md</b> files exported by this editor to ensure lossless restoration.',
    importFileLbl:'Select File', importDesc:'Imported plan will open in a new tab.',
    pvClose:'✕ Exit Preview', pvTitleDef:'Plan Preview', pvTitleFmt:'{name} · Preview', pvFit:'Fit to View',
    tipDblHead:'Double-click to edit header (text / style / merge)', tipDblTime:'Double-click to edit header or shift year/month',
    tipColResize:'Drag to resize column', tipRowResize:'Drag to resize row height', tipBodyClick:'Click timeline to add a milestone',
    tipNode:'Click to edit · Shift+Click or click ＋ to link nodes', tipPort:'Click to link to another milestone',
    tipDragEdit:'Drag to reposition · Click to edit', tipRowDrag:'Drag to reorder row', tipRowAdd:'Insert row below', tipRowDel:'Delete item',
    tipColAdd:'Add column', tipColDel:'Delete column', tipTabClose:'Close tab',
    tStartAfterEnd:'Start date cannot be later than end date', tPosMoved:'Position updated ("Reset Layout" to restore)',
    tRowReordered:'Row order updated', tFitAll:'Timeline fitted to all {n} milestones', tFitEmpty:'No milestones yet; default range restored',
    tRowResized:'Row height updated ("Reset Layout" to restore)', tLeftColResized:'Column width updated',
    tColResized:'Column width set to {w}px ("Reset Layout" to restore)',
    tSelectDate:'Please select a date', tNoItem:'Parent item not found', tNodeDeleted:'Milestone deleted',
    tEnterItem:'Please enter an item name', tRowInserted:'Row inserted below', tColAdded:'Column added (double-click header to edit)',
    tKeepOneCol:'At least one column is required', tColDeleted:'Column deleted', tHeadMergeL:'Header merged left', tHeadMergeR:'Header merged right',
    tHeadSplit:'Header split', tHeadSaved:'Header saved', tMergeD:'Merged down', tMergeR:'Merged right',
    tMergeU:'Merged up', tMergeL:'Merged left', tCellSplit:'Cell split', tCellSaved:'Cell saved',
    tFirstRow:'Already on the first row', tUpperMerged:'Cell above is already merged', tFirstCol:'Already on the first column', tLeftMerged:'Cell to the left is already merged',
    tViewSwitched:'Switched to {v} view', tNoManualPos:'No manual layout adjustments to reset', tResetDone:'Restored {n} layout adjustments',
    tColScaleDone:'Column width synced across timeline', tLineSaved:'Connector style updated',
    tLinkStart:'Start node selected — click another milestone to link (click blank area or Esc to cancel)',
    tLinkStartCancel:'Link start cleared', tLinkDup:'A manual link already exists between these milestones',
    tLinkCreated:'Manual link created', tLinkDeleted:'Manual link deleted', tLinkUpdated:'Manual link style updated',
    tLinkCancelled:'Linking cancelled', tLinkExit:'Exited link mode',
    tInvalidYear:'Enter a valid year (2000–2100)', tInvalidMonth:'Select a valid month',
    tShifted:'Timeline shifted {dir} by {n} month(s){sync}', tDirFwd:'forward', tDirBack:'back', tSyncNote:' (milestones synced)',
    tTimeLabelSaved:'Custom header label saved', tTimeLabelReset:'Default header label restored',
    tNoUndo:'Nothing to undo', tUndone:'Undid last action',
    tNewSheet:'New plan tab created', tKeepOneSheet:'At least one sheet must remain open',
    tCopied:'Copied to clipboard', tCopiedCompat:'Copied (fallback mode)', tDownloaded:'Downloaded {f}',
    tExcelExported:'Exported Excel ({f})', tNoExport:'No items to export', tPngExported:'Exported PNG image',
    tPdfExported:'Exported PDF', tPdfFail:'Failed to generate PDF', tNoPreview:'No items to preview',
    tSaveFull:'Save failed: browser storage may be full', tPlanSaved:'Saved plan "{name}"',
    tPlanSavedLib:'Saved "{name}" to Plan Library', tPlanLoaded:'Loaded plan "{name}"', tPlanDeleted:'Deleted plan "{name}"',
    tImportBad:'No valid editor payload found. Please select a .md file exported by this tool.', tImportErr:'Failed to parse imported data',
    tImportEmpty:'Imported file contains no valid plan data', tImported:'Imported plan "{name}"', tReadFail:'Failed to read file',
    cDelItem:'Delete item "{name}" and its {n} milestone(s)?',
    cCloseTab:'Close tab "{name}"? Unsaved workspace edits will be removed (Plan Library snapshots remain safe).',
    cLoadSample:'Load sample plan? Current edits will be replaced.', cClearAll:'Clear all items? This cannot be undone.',
    cOverwritePlan:'A plan named "{name}" already exists. Overwrite it?', cLoadPlan:'Load "{name}"? Current edits will be overwritten.',
    cDelPlan:'Delete saved plan "{name}"? This cannot be undone.',
    shapes:{ circle:'● Circle', diamond:'◇ Diamond', triangle:'△ Triangle', square:'□ Square', star:'☆ Star', hexagon:'⬡ Hexagon' },
    lstyles:{ solid:'Solid', dashed:'Dashed', dotted:'Dotted' },
    arrows:{ triangle:'▶ Filled Arrow', 'triangle-open':'▷ Hollow Arrow', chevron:'› Chevron', dot:'● Dot', diamond:'◆ Diamond', none:'— None' }
  }
};
function t(key, vars){
  var dict = I18N[curLang] || I18N.zh;
  var str = (dict[key] !== undefined) ? dict[key] : (I18N.zh[key] !== undefined ? I18N.zh[key] : key);
  if(vars && typeof str === 'string'){
    Object.keys(vars).forEach(function(k){ str = str.replace(new RegExp('\\{'+k+'\\}', 'g'), String(vars[k])); });
  }
  return str;
}
var uid = function(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); };
var $ = function(id){ return document.getElementById(id); };
var esc = function(s){
  return String(s==null?'':s).replace(/[&<>"']/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
  });
};

var LEGACY_KEY = 'projectPlanQuickEditor';
var WB_KEY = 'projectPlanQuickEditor.workbook';
var today = new Date();
var todayFmt = fmt(today);

/* 时间线布局常量（像素） */
var MAIN_Y = 39;       /* 节点圆点中心 Y（连接线高度） */
var CHIP_TOP = 58;     /* 第一个任务药丸的 top */
var CHIP_STEP = 24;    /* 任务药丸行距 */
var BASE_H = 92;       /* 无任务时的行高 */
var LBL_TOP = 0;       /* 节点标签带 top */

/* ================= 格式与尺寸辅助 ================= */
var FMT_SIZES = [10, 11, 12, 13, 14, 16, 18, 20, 24];
/* 生成内联 CSS：颜色 / 加粗 / 斜体 / 字号 */
function fmtCss(f, sizePx){
  var s = '';
  if(f){
    if(f.color) s += 'color:'+f.color+';';
    if(f.bold) s += 'font-weight:700;';
    if(f.italic) s += 'font-style:italic;';
  }
  if(sizePx) s += 'font-size:'+sizePx+'px;';
  return s;
}
function fmtEmpty(f){ return !f || (!f.color && !f.bold && !f.italic && !f.size); }
/* ================= 节点图标（形状 / 颜色） ================= */
var NODE_SHAPES = [
  { id:'circle',   label:'● 圆形' },
  { id:'diamond',  label:'◇ 菱形' },
  { id:'triangle', label:'△ 三角形' },
  { id:'square',   label:'□ 方形' },
  { id:'star',     label:'☆ 星形' },
  { id:'hexagon',  label:'⬡ 六边形' }
];
var NODE_COLOR_DEFAULT = '#4f6ef7';
var NODE_SIZE_DEFAULT = 14;
var NODE_SIZE_OPTIONS = [10, 12, 14, 16, 18, 20, 24, 28];
var MANUAL_LINK_COLOR = '#8a5cf6';
function nodeShape(n){ return (n && n.shape) || 'circle'; }
function nodeColor(n){ return (n && n.color) || NODE_COLOR_DEFAULT; }
function nodeSize(n){ return (n && n.size) || NODE_SIZE_DEFAULT; }
/* 返回形状顶点（相对中心、半径 r）；circle 返回 null 走圆绘制 */
function shapePoints(shape, r){
  var pts = [];
  if(shape === 'diamond'){
    pts = [[0,-r],[r,0],[0,r],[-r,0]];
  } else if(shape === 'triangle'){
    pts = [[0,-r],[r*0.92, r*0.72],[-r*0.92, r*0.72]];
  } else if(shape === 'square'){
    var s = r*0.82;
    pts = [[-s,-s],[s,-s],[s,s],[-s,s]];
  } else if(shape === 'hexagon'){
    for(var i=0;i<6;i++){ var a = -Math.PI/2 + i*Math.PI/3; pts.push([Math.cos(a)*r, Math.sin(a)*r]); }
  } else if(shape === 'star'){
    var outer = r, inner = r*0.45;
    for(var k=0;k<10;k++){
      var ang = -Math.PI/2 + k*Math.PI/5;
      pts.push([Math.cos(ang)*(k%2===0?outer:inner), Math.sin(ang)*(k%2===0?outer:inner)]);
    }
  }
  return pts;
}
/* DOM 用：节点图标 SVG（形状 + 颜色，白色描边） */
function nodeShapeSvg(shape, color){
  var r = 6, c = 7;
  if(shape === 'circle'){
    return '<svg viewBox="0 0 14 14"><circle cx="7" cy="7" r="'+r+'" fill="'+color+'" stroke="#fff" stroke-width="2.2"/></svg>';
  }
  var pts = shapePoints(shape, r);
  if(!pts.length) pts = shapePoints('square', r);
  var d = pts.map(function(p){ return ((p[0]+c).toFixed(2))+' '+((p[1]+c).toFixed(2)); }).join(' L ');
  return '<svg viewBox="0 0 14 14"><path d="M '+d+' Z" fill="'+color+'" stroke="#fff" stroke-width="2.2" stroke-linejoin="round"/></svg>';
}
/* Canvas 用：绘制节点图标（支持按节点自定义大小缩放，默认 14px） */
function drawNodeShape(ctx, x, y, shape, color, size){
  size = size || NODE_SIZE_DEFAULT;
  var k = size / NODE_SIZE_DEFAULT;
  var r = 6 * k;
  ctx.beginPath();
  if(shape === 'circle'){
    ctx.arc(x, y, r, 0, Math.PI*2);
  } else {
    var pts = shapePoints(shape, r);
    if(!pts.length) pts = shapePoints('square', r);
    ctx.moveTo(x+pts[0][0], y+pts[0][1]);
    for(var i=1;i<pts.length;i++) ctx.lineTo(x+pts[i][0], y+pts[i][1]);
    ctx.closePath();
  }
  ctx.fillStyle = color;
  ctx.fill();
  ctx.lineWidth = 2.2 * k;
  ctx.strokeStyle = '#ffffff';
  ctx.lineJoin = 'round';
  ctx.stroke();
}
/* ================= 连线样式（颜色 / 粗细 / 虚实 / 箭头形状） ================= */
var ARROW_SHAPES = [
  { id:'triangle',      label:'▶ 实心三角' },
  { id:'triangle-open', label:'▷ 空心三角' },
  { id:'chevron',       label:'› V 形箭头' },
  { id:'dot',           label:'● 圆点' },
  { id:'diamond',       label:'◆ 菱形' },
  { id:'none',          label:'— 无箭头' }
];
var LINE_STYLES = [
  { id:'solid',  label:'实线' },
  { id:'dashed', label:'虚线' },
  { id:'dotted', label:'点线' }
];
var LINE_DEFAULTS = { color:'#4f6ef7', width:2, style:'solid', arrow:'triangle' };
function lineOpts(){
  var L = (data && data.line) || {};
  return {
    color: L.color || LINE_DEFAULTS.color,
    width: L.width || LINE_DEFAULTS.width,
    style: L.style || LINE_DEFAULTS.style,
    arrow: L.arrow || LINE_DEFAULTS.arrow
  };
}
function normalizeLine(){
  data.line = data.line || {};
  data.line.color = data.line.color || LINE_DEFAULTS.color;
  data.line.width = data.line.width || LINE_DEFAULTS.width;
  data.line.style = data.line.style || LINE_DEFAULTS.style;
  data.line.arrow = data.line.arrow || LINE_DEFAULTS.arrow;
}
/* 箭头几何：尖端在原点(0,0)、指向 +X 方向 */
function arrowGeom(arrow, s, h){
  if(arrow === 'dot') return { kind:'dot', cx:-s*0.5, cy:0, r:Math.max(2, h*0.55) };
  var pts, fill, close;
  if(arrow === 'triangle'){ pts=[[0,0],[-s,-h],[-s,h]]; fill=true; close=true; }
  else if(arrow === 'triangle-open'){ pts=[[0,0],[-s,-h],[-s,h]]; fill=false; close=true; }
  else if(arrow === 'chevron'){ pts=[[-s,-h],[0,0],[-s,h]]; fill=false; close=false; }
  else if(arrow === 'diamond'){ pts=[[0,0],[-s*0.5,-h],[-s,0],[-s*0.5,h]]; fill=true; close=true; }
  else { pts=[[0,0],[-s,-h],[-s,h]]; fill=true; close=true; }
  return { kind:'poly', pts:pts, fill:fill, close:close };
}
function arrowSize(width){ return { s:6 + width*1.6, h:3.5 + width*0.9 }; }
/* DOM：生成箭头 <g> */
function arrowHeadSvg(x1, y1, x2, y2, arrow, color, width){
  var sz = arrowSize(width);
  var deg = Math.atan2(y2-y1, x2-x1) * 180/Math.PI;
  var g = arrowGeom(arrow, sz.s, sz.h);
  var inner = '';
  if(g.kind === 'dot'){
    inner = '<circle cx="'+g.cx+'" cy="'+g.cy+'" r="'+Math.round(g.r*100)/100+'" fill="'+color+'"/>';
  } else {
    var d = 'M ' + g.pts.map(function(p){ return p[0].toFixed(2)+' '+p[1].toFixed(2); }).join(' L ');
    if(g.close) d += ' Z';
    if(g.fill){
      inner = '<path d="'+d+'" fill="'+color+'" stroke-linejoin="round"/>';
    } else {
      var sw = Math.max(1.4, width*0.7).toFixed(1);
      inner = '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="'+sw+'" stroke-linecap="round" stroke-linejoin="round"/>';
    }
  }
  return '<g transform="translate('+x2.toFixed(2)+' '+y2.toFixed(2)+') rotate('+deg.toFixed(2)+')">'+inner+'</g>';
}
/* Canvas：绘制箭头 */
function drawArrowHead(ctx, x1, y1, x2, y2, arrow, color, width){
  var sz = arrowSize(width);
  var ang = Math.atan2(y2-y1, x2-x1);
  var g = arrowGeom(arrow, sz.s, sz.h);
  ctx.save();
  ctx.translate(x2, y2);
  ctx.rotate(ang);
  if(g.kind === 'dot'){
    ctx.beginPath();
    ctx.arc(g.cx, g.cy, g.r, 0, Math.PI*2);
    ctx.fillStyle = color;
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(g.pts[0][0], g.pts[0][1]);
    for(var i=1;i<g.pts.length;i++) ctx.lineTo(g.pts[i][0], g.pts[i][1]);
    if(g.close) ctx.closePath();
    if(g.fill){
      ctx.fillStyle = color;
      ctx.fill();
    } else {
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1.4, width*0.7);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
    }
  }
  ctx.restore();
}
/* 节点标签盒高度（按字号估算） */
function nodeLblH(n){
  var S = (n && n.fmt && n.fmt.size) || 11;
  return Math.round(S*2.5 + 4.75);
}
/* 节点任务行距：按最大字号自适应，避免大字号重叠 */
function nodeTaskStep(n){
  var max = CHIP_STEP;
  (n.tasks||[]).forEach(function(t, tk){
    var f = (n.tFmt && n.tFmt[tk]) || {};
    var sz = f.size || 11;
    var h = Math.ceil(sz*1.6 + 6);
    if(h > max) max = h;
  });
  return max;
}
/* 日期在时间轴中的列索引；不在范围内返回 -1（不显示） */
function colIdxOf(cols, dateStr){
  for(var i = 0; i < cols.length; i++){
    if(inCol(cols[i], dateStr)) return i;
  }
  return -1;
}
/* 事项行的自动高度（基础默认高度，含标签撑高与任务行距自适应） */
function itemAutoH(it){
  var vis = it.nodes.filter(function(n){ return n.date >= data.start && n.date <= data.end; });
  var lpad = vis.reduce(function(m,n){ return Math.max(m, Math.max(0, nodeLblH(n)-32)); }, 0);
  vis.forEach(function(n){ lpad = Math.max(lpad, Math.max(0, MAIN_Y + nodeSize(n)/2 - CHIP_TOP)); });
  var contentH = vis.reduce(function(m,n){
    return Math.max(m, n.tasks.length ? CHIP_TOP + n.tasks.length*nodeTaskStep(n) + 14 : 0);
  }, BASE_H);
  return contentH + lpad;
}
/* 事项行可见内容区高度（标签顶 0 → 最后元素底，用于行高加高后居中） */
function itemContentH(it){
  var vis = it.nodes.filter(function(n){ return n.date >= data.start && n.date <= data.end; });
  var maxB = 46; /* 圆点底：MAIN_Y + 默认半径 */
  vis.forEach(function(n){
    maxB = Math.max(maxB, MAIN_Y + nodeSize(n)/2); /* 图标底 */
    maxB = Math.max(maxB, nodeLblH(n)); /* 标签底 */
    (n.tasks||[]).forEach(function(t, tk){
      var f = (n.tFmt && n.tFmt[tk]) || {};
      var TS = f.size || 11;
      var chipH = Math.max(20, Math.round(TS*1.6 + 4));
      maxB = Math.max(maxB, CHIP_TOP + tk*nodeTaskStep(n) + chipH);
    });
  });
  return maxB;
}
/* 行高加高后的垂直居中偏移：未加高时为 0（保持默认布局） */
function rowCoff(it, rowH){
  var h = (it.hAdj || 0);
  return h > 0 ? Math.max(0, Math.round((rowH - itemContentH(it)) / 2)) : 0;
}

/* ================= 数据 ================= */
/* 示例模版：V车型项目开发计划表（整车开发主流程：预研立项 → 造型工程 → 试制试验 → 生产量产，数据与 V车型项目开发计划表示例.md 一致） */
var V_MODEL_SAMPLE = {"v":1,"name":"V车型项目开发计划表示例","start":"2026-08-06","end":"2027-10-07","view":"month","colScale":1,"leftCols":[{"label":"阶段","w":140},{"label":"关键事项","w":250}],"merges":[{"r":3,"c":0,"rs":2,"cs":1},{"r":5,"c":0,"rs":3,"cs":1},{"r":8,"c":0,"rs":2,"cs":1},{"r":10,"c":0,"rs":2,"cs":1},{"r":0,"c":0,"rs":1,"cs":2},{"r":1,"c":0,"rs":1,"cs":2},{"r":2,"c":0,"rs":1,"cs":2}],"items":[{"id":"mt1lq3186hhc1","name":"阀门节点示例","cells":[{"text":"阀门节点示例"},{"text":""}],"nodes":[{"id":"mt1lr0ps47zlp","date":"2026-08-06","title":"G9阀","tasks":[],"shape":"star","size":24},{"id":"mt1lrzgg4u5jd","date":"2026-09-15","title":"G8阀","tasks":[],"shape":"star","color":"#ff2600","size":24},{"id":"mt1lt0zcm0enk","date":"2026-10-30","title":"G7阀","tasks":[],"shape":"star","color":"#0433ff","size":24},{"id":"mt1ltxxhnktqc","date":"2026-12-24","title":"G6阀","tasks":[],"shape":"star","color":"#0056d6","size":24},{"id":"mt1lui9pgq8li","date":"2027-01-28","title":"G5阀","tasks":[],"shape":"star","size":24},{"id":"mt1lvgxmpppwl","date":"2027-02-26","title":"G3阀","tasks":["PT1/VFF生产"],"shape":"star","size":24},{"id":"mt1lvv71odocp","date":"2027-06-24","title":"G2阀","tasks":["PT2/0S生产"],"shape":"star","size":24},{"id":"mt1lwkw9mkk4d","date":"2027-08-30","title":"G1阀","tasks":["SOP量产"],"shape":"star","size":24,"fmt":{"color":"#ff2600"},"color":"#ff2600"}],"hAdj":36},{"id":"mt1lxyolaiy0z","name":"软件开发计划示例","cells":[{"text":"软件开发计划示例"},{"text":""}],"nodes":[{"id":"mt1lyp1gpxrek","date":"2026-10-01","title":"VR2.0提测","tasks":[]},{"id":"mt1lz0j117fjm","date":"2026-11-20","title":"VR2.0发布","tasks":[]},{"id":"mt1m0aqjkhhu8","date":"2027-01-08","title":"VP2.0发布","tasks":[]},{"id":"mt1m0lf7bo17r","date":"2027-02-24","title":"VP2.0发布","tasks":[]},{"id":"mt1m1kywevhni","date":"2027-03-05","title":"SR1.0提测","tasks":[],"lblOff":{"x":46.22127016129025,"y":-2.234375}},{"id":"mt1m20e09b7i5","date":"2027-04-22","title":"SR1.0发布","tasks":[],"lblOff":{"x":-22.203125,"y":-0.109375}},{"id":"mt1m2msqgrjkt","date":"2027-05-01","title":"SR1.1提测","tasks":[],"lblOff":{"x":18.20564516129025,"y":0}},{"id":"mt1m2uoygltdh","date":"2027-06-18","title":"SR1.1.发布","tasks":[]},{"id":"mt1m34co0dqmc","date":"2027-07-09","title":"SR2.0提测","tasks":[]},{"id":"mt1m3eg9b9rjp","date":"2027-08-23","title":"SR2.0发布","tasks":[]}],"hAdj":11},{"id":"mt1m5tsrx5xiz","name":"XX专业开发计划","cells":[{"text":"XX专业开发计划"},{"text":""}],"nodes":[{"id":"mt1m7wpz765y1","date":"2026-09-01","title":"节点1","tasks":[]},{"id":"mt1m836g2i52l","date":"2026-10-01","title":"节点2","tasks":[]},{"id":"mt1m86is4nplp","date":"2026-11-01","title":"节点3","tasks":[]},{"id":"mt1m89ln5px54","date":"2027-01-01","title":"节点4","tasks":["任务N"]},{"id":"mt1m8ch6vwwu2","date":"2027-03-01","title":"节点5","tasks":[]},{"id":"mt1m8flmu7v3h","date":"2027-05-01","title":"节点6","tasks":[]},{"id":"mt1m8ifrbs3l6","date":"2027-06-01","title":"节点7","tasks":[]},{"id":"mt1m8la1lputa","date":"2027-07-01","title":"节点8","tasks":[]},{"id":"mt1m8nu5i96xv","date":"2027-07-30","title":"节点9","tasks":[]},{"id":"mt1m8rctqvq25","date":"2027-08-20","title":"节点10","tasks":[]}],"hAdj":14},{"id":"mt1ljt3tvf9yw","name":"预研与立项","cells":[{"text":"预研与立项","fmt":{"bold":true,"color":"#4f6ef7"}},{"text":"市场调研与竞品分析"}],"nodes":[{"id":"mt1ljt3t56ya2","date":"2026-08-25","title":"竞品分析与市场调研","tasks":["完成市场洞察报告","对标 C 级标杆车型"],"lblOff":{"x":-45.28276209677419,"y":1.5},"taskOff":{"0":{"x":-29.876512096774192,"y":-0.109375},"1":{"x":-24.392137096774192,"y":0.8125}}},{"id":"mt1ljt3tstd4l","date":"2026-09-01","title":"技术可行性评估","tasks":["平台与动力选型","成本初步测算"],"lblOff":{"x":59.578125,"y":1.09375},"taskOff":{"0":{"x":70.078125,"y":-1.546875},"1":{"x":68.1875,"y":2.890625}}}]},{"id":"mt1ljt3t70tbk","name":"预研与立项","cells":[{"text":"预研与立项"},{"text":"立项与项目启动"}],"nodes":[{"id":"mt1ljt3tq34s6","date":"2026-09-09","title":"项目立项评审","shape":"diamond","tasks":["董事会立项审批","批准项目目标"],"lblOff":{"x":-39.59375,"y":1.09375},"taskOff":{"0":{"x":-46.5625,"y":-0.125},"1":{"x":-38.25,"y":0}}},{"id":"mt1ljt3t4ddgd","date":"2026-09-15","title":"项目启动（K0）","shape":"star","size":16,"fmt":{"bold":true},"tasks":["召开项目启动会","发布项目主计划"],"lblOff":{"x":95.734375,"y":-0.46875},"taskOff":{"0":{"x":67.9375,"y":0.234375},"1":{"x":72.96875,"y":2.75}}}]},{"id":"mt1ljt3tihgjq","name":"造型与工程设计","cells":[{"text":"造型与工程设计","fmt":{"bold":true,"color":"#e58a2e"}},{"text":"造型设计与评审"}],"nodes":[{"id":"mt1ljt3tbsuub","date":"2026-10-04","title":"造型方向提案","tasks":["多方案造型提案","管理层评审确认"]},{"id":"mt1ljt3tv8k5h","date":"2026-10-29","title":"造型冻结","shape":"diamond","size":18,"color":"#e5484d","fmt":{"bold":true,"color":"#e5484d"},"tasks":["油泥模型评审冻结","造型数据发布"]}]},{"id":"mt1ljt3t77wc3","name":"造型与工程设计","cells":[{"text":"造型与工程设计"},{"text":"工程设计（数据开发）"}],"nodes":[{"id":"mt1ljt3tvdntc","date":"2026-11-18","title":"工程数据发布","tasks":["白车身/内外饰数据","DMU 干涉检查通过"]},{"id":"mt1ljt3tdtfax","date":"2026-12-13","title":"开模指令发布","shape":"square","tasks":["模具/夹具定点","供应商开模启动"]}]},{"id":"mt1ljt3tqu5lt","name":"造型与工程设计","cells":[{"text":"造型与工程设计"},{"text":"虚拟仿真验证"}],"nodes":[{"id":"mt1ljt3t33lpf","date":"2027-01-02","title":"CAE 分析完成","shape":"hexagon","color":"#8a5cf6","tasks":["碰撞/强度/模态分析","虚拟验证报告发布"],"tFmt":{"0":{"bold":true}}}]},{"id":"mt1ljt3tkbdzb","name":"试制与试验验证","cells":[{"text":"试制与试验验证","fmt":{"bold":true,"color":"#8a5cf6"}},{"text":"样车试制"}],"nodes":[{"id":"mt1ljt3tjm0xp","date":"2027-01-22","title":"骡车试制完成","tasks":["底盘与动力总成集成","骡车试验启动"]},{"id":"mt1ljt3tyuxgd","date":"2027-02-16","title":"工程样车下线","shape":"square","tasks":["EP 样车下线","静动态评审"]}]},{"id":"mt1ljt3t14c0r","name":"试制与试验验证","cells":[{"text":"试制与试验验证"},{"text":"整车试验验证"}],"nodes":[{"id":"mt1ljt3tzdwws","date":"2027-03-13","title":"DV 试验完成","tasks":["零部件级验证","台架试验完成"]},{"id":"mt1ljt3tyyis4","date":"2027-04-12","title":"可靠性路试完成","fmt":{"bold":true},"tasks":["耐久性路试","三高试验（高温/高原/高寒）"],"tFmt":{"1":{"size":12}}}]},{"id":"mt1ljt3tk0fal","name":"生产准备与量产","cells":[{"text":"生产准备与量产","fmt":{"bold":true,"color":"#0aa06e"}},{"text":"生产准备（PVS/PPAP）"}],"nodes":[{"id":"mt1ljt3tb4egt","date":"2027-05-02","title":"PVS 试生产","shape":"hexagon","tasks":["预批量试生产","工艺验证"]},{"id":"mt1ljt3tuxppv","date":"2027-05-19","title":"PPAP 批准","tasks":["生产件批准","产能验证达成"]}]},{"id":"mt1ljt3tl6pph","name":"生产准备与量产","cells":[{"text":"生产准备与量产"},{"text":"量产启动（SOP）"}],"nodes":[{"id":"mt1ljt3t88efs","date":"2027-08-26","title":"SOP 量产启动","shape":"star","size":20,"color":"#e5484d","fmt":{"color":"#e5484d","bold":true},"tasks":["正式量产（SOP）","市场投放启动"],"taskOff":{"0":{"x":-71.6875,"y":-0.875},"1":{"x":-53.703125,"y":9.3125}}},{"id":"mt1ljt3tr205y","date":"2027-09-30","title":"产能爬坡达成","tasks":["单班产能达标","质量目标达成"],"lblOff":{"x":-10.921875,"y":-2.4375},"taskOff":{"0":{"x":18.609375,"y":0},"1":{"x":35.84375,"y":1.859375}}}]}],"links":[{"id":"mt1ljt3t8ip4g","a":{"iid":"mt1ljt3t70tbk","nid":"mt1ljt3t4ddgd"},"b":{"iid":"mt1ljt3tihgjq","nid":"mt1ljt3tbsuub"},"width":2,"style":"solid"},{"id":"mt1ljt3tkwl1d","a":{"iid":"mt1ljt3tihgjq","nid":"mt1ljt3tv8k5h"},"b":{"iid":"mt1ljt3t77wc3","nid":"mt1ljt3tdtfax"},"width":2,"style":"dashed"},{"id":"mt1lz5wmuhag9","a":{"iid":"mt1lxyolaiy0z","nid":"mt1lyp1gpxrek"},"b":{"iid":"mt1lxyolaiy0z","nid":"mt1lz0j117fjm"},"width":5,"style":"solid"},{"id":"mt1m0tpmwq2vh","a":{"iid":"mt1lxyolaiy0z","nid":"mt1m0aqjkhhu8"},"b":{"iid":"mt1lxyolaiy0z","nid":"mt1m0lf7bo17r"},"width":5,"style":"solid"},{"id":"mt1m2439j2hcy","a":{"iid":"mt1lxyolaiy0z","nid":"mt1m1kywevhni"},"b":{"iid":"mt1lxyolaiy0z","nid":"mt1m20e09b7i5"},"width":5,"style":"solid"},{"id":"mt1m3jtcvqp31","a":{"iid":"mt1lxyolaiy0z","nid":"mt1m2msqgrjkt"},"b":{"iid":"mt1lxyolaiy0z","nid":"mt1m2uoygltdh"},"width":5,"style":"solid"},{"id":"mt1m3p8rf6acc","a":{"iid":"mt1lxyolaiy0z","nid":"mt1m34co0dqmc"},"b":{"iid":"mt1lxyolaiy0z","nid":"mt1m3eg9b9rjp"},"width":5,"style":"solid"}],"line":{"color":"#4f6ef7","width":2,"style":"solid","arrow":"triangle"}};

function defaultData(){
  return JSON.parse(JSON.stringify(V_MODEL_SAMPLE));
}
function emptyData(){
  return { v:1, name:'未命名项目', start:todayFmt, end:fmt(addDays(today,30)), view:'week',
           colScale:1, leftCols:[{ label:'事项', w:180 }], merges:[], items:[],
           links:[],
           line:{ color:'#4f6ef7', width:2, style:'solid', arrow:'triangle' } };
}
var sheets = [];
var activeIndex = 0;
function loadWorkbook(){
  /* 新版：多计划表工作区 */
  try{
    var raw = localStorage.getItem(WB_KEY);
    if(raw){
      var wb = JSON.parse(raw);
      if(wb && Array.isArray(wb.sheets) && wb.sheets.length){
        sheets = wb.sheets;
        activeIndex = Math.min(Math.max(0, wb.active || 0), sheets.length - 1);
        return;
      }
    }
  }catch(e){}
  /* 迁移旧版：单计划表 */
  try{
    var old = localStorage.getItem(LEGACY_KEY);
    if(old){
      var d = JSON.parse(old);
      if(d && d.v === 1){
        sheets = [d];
        activeIndex = 0;
        try{ localStorage.removeItem(LEGACY_KEY); }catch(e){}
        return;
      }
    }
  }catch(e){}
  sheets = [defaultData()];
  activeIndex = 0;
}
/* 兼容旧数据：左侧多列 + 每行 cells + 合并 merges */
function normalizeData(){
  if(!data.leftCols || !data.leftCols.length){
    data.leftCols = [{ label: data.itemLabel || '事项', w: data.itemW || 180 }];
  }
  if(!data.merges) data.merges = [];
  if(!data.links) data.links = [];
  if(!data.colWidths || typeof data.colWidths !== 'object') data.colWidths = {};
  if(!data.timeLabels || typeof data.timeLabels !== 'object') data.timeLabels = {};
  data.items.forEach(function(it){
    if(!it.cells || !it.cells.length) it.cells = [{ text: it.name || '未命名' }];
    while(it.cells.length < data.leftCols.length) it.cells.push({ text:'' });
    it.cells = it.cells.slice(0, data.leftCols.length);
    if(it.cells[0]) it.name = it.cells[0].text || '未命名';
  });
  normalizeLine();
  normalizeMerges();
}
function save(){
  sheets[activeIndex] = data;
  try{ localStorage.setItem(WB_KEY, JSON.stringify({ active: activeIndex, sheets: sheets })); }catch(e){}
}
function findItem(iid){
  return data.items.find(function(x){ return x.id===iid; });
}
function findNode(iid, nid){
  var it = data.items.find(function(x){ return x.id===iid; });
  return it ? it.nodes.find(function(n){ return n.id===nid; }) : null;
}

/* ================= 左侧事项网格（多列 + 合并） ================= */
function leftTotalW(){
  return data.leftCols.reduce(function(s,c){ return s+c.w; }, 0);
}
function leftOffsets(){
  var o = [], s = 0;
  data.leftCols.forEach(function(c){ o.push(s); s += c.w; });
  return o;
}
function leftCell(it, c){
  return (it.cells && it.cells[c]) || { text:'' };
}
/* 表头覆盖映射：列索引 -> 表头锚点列（支持跨列合并标题） */
function headerCoverage(){
  var cov = {};
  var M = data.leftCols.length;
  for(var c = 0; c < M; ){
    var cs = Math.min(Math.max(1, data.leftCols[c].cs || 1), M - c);
    for(var k = c; k < c + cs; k++) cov[k] = c;
    c += cs;
  }
  return cov;
}
/* 表头跨度规范化：锚点列的 cs 不越界，被覆盖列的 cs 复位为 1 */
function normalizeHeaderSpans(){
  var M = data.leftCols.length;
  var c = 0;
  while(c < M){
    data.leftCols[c].cs = Math.min(Math.max(1, data.leftCols[c].cs || 1), M - c);
    c += data.leftCols[c].cs;
  }
  var cov = headerCoverage();
  for(var k = 0; k < M; k++){
    if(cov[k] !== k) data.leftCols[k].cs = 1;
  }
}
/* 合并覆盖映射："r,c" -> 合并对象（锚点） */
function leftCoverage(){
  var cov = {};
  (data.merges||[]).forEach(function(m){
    for(var i = m.r; i < m.r + m.rs; i++){
      for(var j = m.c; j < m.c + m.cs; j++){
        cov[i+','+j] = m;
      }
    }
  });
  return cov;
}
/* 合并边界规范化（裁剪越界、丢弃无效） */
function normalizeMerges(){
  var R = data.items.length, M = data.leftCols.length;
  data.merges = (data.merges||[]).filter(function(m){
    if(m.r < 0 || m.c < 0 || m.r >= R || m.c >= M) return false;
    m.rs = Math.min(m.rs, R - m.r);
    m.cs = Math.min(m.cs, M - m.c);
    return m.rs > 1 || m.cs > 1;
  });
}

loadWorkbook();
var data = sheets[activeIndex];
normalizeData();

/* ================= 表格构建 ================= */
function buildColumns(start, end, view){
  var cols = [], cur = new Date(start);
  while(cur <= end){
    if(view === 'day'){
      cols.push({ type:'day', date:new Date(cur), dow:cur.getDay() });
      cur = addDays(cur,1);
    } else if(view === 'week'){
      var ws = weekStart(cur), we = addDays(ws,6);
      cols.push({ type:'week', date:new Date(ws) });
      cur = addDays(we,1);
    } else {
      cols.push({ type:'month', date:new Date(cur.getFullYear(), cur.getMonth(), 1) });
      cur = new Date(cur.getFullYear(), cur.getMonth()+1, 1);
    }
  }
  return cols;
}
function colLabel(c){
  if(c.type === 'day'){
    return c.date.getDate()+' '+(curLang === 'en' ? WD_EN[c.date.getDay()] : WD[c.date.getDay()]);
  }
  if(c.type === 'week'){
    var we = addDays(c.date,6);
    return (c.date.getMonth()+1)+'/'+c.date.getDate()+'\u2013'+(we.getMonth()+1)+'/'+we.getDate();
  }
  return curLang === 'en' ? MON_EN[c.date.getMonth()] : ((c.date.getMonth()+1)+'月');
}
function colGroupKey(c){
  if(c.type === 'month') return String(c.date.getFullYear());
  return c.date.getFullYear()+'-'+(c.date.getMonth()+1);
}
function colGroupLabel(c){
  if(c.type === 'month') return curLang === 'en' ? String(c.date.getFullYear()) : (c.date.getFullYear()+'年');
  return curLang === 'en' ? (MON_EN[c.date.getMonth()]+' '+c.date.getFullYear()) : (c.date.getFullYear()+'年'+(c.date.getMonth()+1)+'月');
}
/* 时间列唯一键、列宽与可自定义时间标题 */
function colKey(c){
  if(c.type === 'day') return 'd:' + fmt(c.date);
  if(c.type === 'week') return 'w:' + fmt(c.date);
  return 'm:' + c.date.getFullYear() + '-' + pad(c.date.getMonth()+1);
}
function segLabelKey(c){
  return 'seg:' + data.view + ':' + colGroupKey(c);
}
function segLabelText(c){
  var k = segLabelKey(c);
  return (data.timeLabels && data.timeLabels[k]) || colGroupLabel(c);
}
function colLabelText(c){
  var k = 'col:' + colKey(c);
  return (data.timeLabels && data.timeLabels[k]) || colLabel(c);
}
function baseColWOf(view){
  return ({ day:92, week:120, month:150 }[view] || 120);
}
function colWOf(c){
  var k = colKey(c);
  if(data.colWidths && data.colWidths[k]) return data.colWidths[k];
  return Math.round(baseColWOf(data.view) * (data.colScale || 1));
}
function inCol(c, dateStr){
  var d = parse(dateStr);
  if(c.type === 'day') return sameDay(d, c.date);
  if(c.type === 'week'){
    var we = addDays(c.date,6);
    return d >= c.date && d <= we;
  }
  return d.getFullYear()===c.date.getFullYear() && d.getMonth()===c.date.getMonth();
}
function colEnd(c){
  if(c.type === 'day') return fmt(c.date);
  if(c.type === 'week') return fmt(addDays(c.date,6));
  return fmt(new Date(c.date.getFullYear(), c.date.getMonth()+1, 0));
}

function render(){
  var start = parse(data.start), end = parse(data.end);
  if(start > end){ toast(t('tStartAfterEnd')); return; }
  var cols = buildColumns(start, end, data.view);
  var N = cols.length;
  /* 列宽变量：时间列整轴同步（--colw） */
  var baseColW = { day:92, week:120, month:150 }[data.view] || 120;
  $('tableWrap').style.setProperty('--colw', Math.round(baseColW * (data.colScale||1)) + 'px');
  $('colScaleSel').value = String(data.colScale||1);

  /* ---- 表头 ---- */
  var M = data.leftCols.length;
  var loff = leftOffsets();
  var totalLW = leftTotalW();
  var hc = headerCoverage();
  var h = '<tr>';
  for(var c = 0; c < M; c++){
    if(hc[c] !== c) continue;
    var cs = data.leftCols[c].cs || 1;
    var cw = 0, k; for(k = c; k < c+cs; k++) cw += data.leftCols[k].w;
    var col = data.leftCols[c];
    var hHandles = '';
    for(var hk0 = c; hk0 < c + cs; hk0++){
      var bx0 = 0, bk0; for(bk0 = c; bk0 <= hk0; bk0++) bx0 += data.leftCols[bk0].w;
      hHandles += '<div class="col-resize" data-c="'+hk0+'" style="left:'+(bx0 - 9)+'px" title="拖动调整该列宽度"></div>';
    }
    h += '<th class="corner lc-h" rowspan="2"' + (cs > 1 ? ' colspan="'+cs+'"' : '') + ' data-c="'+c+'" style="width:'+cw+'px;min-width:'+cw+'px;max-width:'+cw+'px;left:'+loff[c]+'px">' +
         '<span class="lc-label" style="'+fmtCss(col.fmt, (col.fmt && col.fmt.size) || 12)+'" title="'+esc(t('tipDblHead'))+'">'+esc(col.label)+'</span>' +
         '<span class="lc-hbtns">' +
         (c + cs >= M ? '<button type="button" class="lc-btn lc-add" title="'+esc(t('tipColAdd'))+'">＋</button>' : '') +
         (M > 1 ? '<button type="button" class="lc-btn lc-del" data-c="'+c+'" title="'+esc(t('tipColDel'))+'">✕</button>' : '') +
         '</span>' +
         hHandles +
         '</th>';
  }
  var i = 0;
  while(i < cols.length){
    var key = colGroupKey(cols[i]), j = i;
    while(j < cols.length && colGroupKey(cols[j]) === key) j++;
    h += '<th class="seg" colspan="'+(j-i)+'" data-seg-key="'+esc(segLabelKey(cols[i]))+'" data-col-date="'+fmt(cols[i].date)+'" data-def-label="'+esc(colGroupLabel(cols[i]))+'" title="'+esc(t('tipDblTime'))+'">'+esc(segLabelText(cols[i]))+'</th>';
    i = j;
  }
  h += '</tr><tr>';
  cols.forEach(function(c, ci){
    var cls = 'day-head' + (c.dow===0 || c.dow===6 ? ' end' : '');
    var ck = colKey(c), cw2 = colWOf(c);
    h += '<th class="'+cls+'" data-col-idx="'+ci+'" data-col-key="'+esc(ck)+'" data-col-date="'+fmt(c.date)+'" data-def-label="'+esc(colLabel(c))+'" style="width:'+cw2+'px;min-width:'+cw2+'px;max-width:'+cw2+'px" title="'+esc(t('tipDblTime'))+'">' +
         esc(colLabelText(c)) +
         '<div class="tcol-resize" data-col-key="'+esc(ck)+'" data-col-idx="'+ci+'" title="'+esc(t('tipColResize'))+'"></div>' +
         '</th>';
  });
  h += '</tr>';
  $('thead').innerHTML = h;

  /* ---- 表体 ---- */
  var tIdx = -1;
  if(data.view === 'day'){
    tIdx = cols.findIndex(function(c){ return c.type==='day' && sameDay(c.date, today); });
  }
  var b = '';
  if(data.items.length === 0){
    b += '<tr><td class="item-col empty" colspan="'+(M+N)+'">'+esc(t('emptyTable'))+'</td></tr>';
  }
  var cov = leftCoverage();
  data.items.forEach(function(it, rIdx){
    var nodes = it.nodes.slice().sort(function(a,bb){ return a.date < bb.date ? -1 : (a.date > bb.date ? 1 : (a.title < bb.title ? -1 : 1)); });
    /* 严格按起止日期过滤（周视图列可能跨月，超出范围一律不显示） */
    var vis = nodes.filter(function(n){ return n.date >= data.start && n.date <= data.end; });
    var autoH = itemAutoH(it);
    var contentH = vis.reduce(function(m,n){
      return Math.max(m, n.tasks.length ? CHIP_TOP + n.tasks.length*nodeTaskStep(n) + 14 : 0);
    }, BASE_H);
    var lpad = autoH - contentH;
    var rowH = autoH + (it.hAdj || 0);
    /* 行高加高后让行内时间线整体垂直居中（未加高保持默认布局） */
    var coff = rowCoff(it, rowH);

    b += '<tr class="item-row" data-iid="'+it.id+'" data-lpad="'+lpad+'" data-coff="'+coff+'">';
    /* 左侧事项网格（多列，跳过被合并覆盖的单元格） */
    for(var c = 0; c < M; c++){
      var m = cov[rIdx+','+c];
      if(m && !(m.r === rIdx && m.c === c)) continue;
      var rs = m ? m.rs : 1, cs = m ? m.cs : 1;
      var cw = 0, k; for(k = c; k < c+cs; k++) cw += data.leftCols[k].w;
      var cell = leftCell(it, c);
      var cText = cell.text || (c === 0 ? (it.name || '') : '');
      /* 合并后的节点/任务数汇总（第 0 列跨行合并时聚合所有行） */
      var metaNodes = vis.length, metaTasks = vis.reduce(function(s,n){ return s+n.tasks.length; },0);
      if(c === 0 && m && m.rs > 1){
        metaNodes = 0; metaTasks = 0;
        for(var rr = m.r; rr < m.r + m.rs && rr < data.items.length; rr++){
          var it2 = data.items[rr];
          var vis2 = it2.nodes.filter(function(n){ return n.date >= data.start && n.date <= data.end; });
          metaNodes += vis2.length;
          vis2.forEach(function(n){ metaTasks += n.tasks.length; });
        }
      }
      b += '<th class="item-col" data-r="'+rIdx+'" data-c="'+c+'"' +
           (rs > 1 ? ' rowspan="'+rs+'"' : '') + (cs > 1 ? ' colspan="'+cs+'"' : '') +
           ' style="width:'+cw+'px;min-width:'+cw+'px;max-width:'+cw+'px;left:'+loff[c]+'px">' +
           '<div class="lc-text" style="'+fmtCss(cell.fmt, (cell.fmt && cell.fmt.size) || 14)+'">'+esc(cText)+'</div>' +
           (c === 0 ? '<button type="button" class="row-drag" data-iid="'+it.id+'" title="'+esc(t('tipRowDrag'))+'">⠿</button>' +
                      '<div class="item-meta">'+esc(t('metaFmt', { n:metaNodes, t:metaTasks }))+'</div>' +
                      '<div class="row-btns">' +
                        '<button type="button" class="icon-btn row-add" data-r="'+rIdx+'" title="'+esc(t('tipRowAdd'))+'">＋</button>' +
                        '<button type="button" class="icon-btn del-item" data-iid="'+it.id+'" title="'+esc(t('tipRowDel'))+'">✕</button>' +
                      '</div>' : '') +
           /* 列宽手柄：该单元格覆盖的每一列右缘 */
           (function(){
             var s = '';
             for(var hk = c; hk < c + cs; hk++){
               var bx = 0, bk; for(bk = c; bk <= hk; bk++) bx += data.leftCols[bk].w;
               /* 手柄完全落在本列内（右缘对齐边界），避免被相邻 sticky 单元格遮挡 */
               s += '<div class="col-resize" data-c="'+hk+'" style="left:'+(bx - 9)+'px" title="'+esc(t('tipColResize'))+'"></div>';
             }
             return s;
           })() +
           '</th>';
    }
    b += '<td class="row-body" colspan="'+N+'" data-iid="'+it.id+'" data-cols="'+N+'" data-tidx="'+tIdx+'" style="height:'+rowH+'px" title="'+esc(t('tipBodyClick'))+'">';
    if(tIdx >= 0){
      b += '<div class="today-col"></div>';
    }
    b += '<div class="guides"></div>';
    cols.forEach(function(colObj, ci){
      b += '<div class="tcol-resize" data-col-key="'+esc(colKey(colObj))+'" data-col-idx="'+ci+'" title="'+esc(t('tipColResize'))+'"></div>';
    });
    b += '<div class="timeline-track" style="top:'+(38+lpad+coff)+'px"></div>';
    b += '<svg class="track"></svg>';
    b += '<div class="row-grip" title="'+esc(t('tipRowResize'))+'"></div>';
    b += '<div class="row-resize" title="'+esc(t('tipRowResize'))+'"></div>';
    if(vis.length === 0){
      var hint = nodes.length === 0 ? t('emptyRow') : t('emptyRowRange');
      b += '<div class="empty-hint">'+esc(hint)+'</div>';
    }
    vis.forEach(function(n){
      var d = parse(n.date);
      var F = n.fmt || {};
      var S = F.size || 11;
      var nsz = nodeSize(n);
      /* 位置在 layoutRow 中按表头列精确计算（此处仅占位） */
      b += '<div class="node" data-iid="'+it.id+'" data-nid="'+n.id+'" data-date="'+n.date+'" data-size="'+nsz+'" style="left:0;top:'+(MAIN_Y - nsz/2 + lpad + coff)+'px" title="'+esc(t('tipNode'))+'">' +
           '<div class="node-dot" style="width:'+nsz+'px;height:'+nsz+'px">'+nodeShapeSvg(nodeShape(n), nodeColor(n))+'</div>' +
           '<button type="button" class="node-link-port" data-iid="'+it.id+'" data-nid="'+n.id+'" title="'+esc(t('tipPort'))+'">＋</button></div>';
      b += '<div class="node-lbl" data-iid="'+it.id+'" data-nid="'+n.id+'" data-date="'+n.date+'" style="left:0;top:'+(LBL_TOP+coff)+'px" title="'+esc(t('tipDragEdit'))+'">' +
           '<span class="t" style="'+fmtCss(F, S)+'">'+esc(n.title||'未命名')+'</span>' +
           '<span class="d" style="'+fmtCss(F, Math.max(8, S-1))+'">'+(d.getMonth()+1)+'/'+d.getDate()+'</span></div>';
      n.tasks.forEach(function(t2,tk){
        var TF = (n.tFmt && n.tFmt[tk]) || {};
        b += '<div class="task-chip" data-iid="'+it.id+'" data-nid="'+n.id+'" data-date="'+n.date+'" data-k="'+tk+'" style="left:0;top:'+(CHIP_TOP+tk*nodeTaskStep(n)+lpad+coff)+'px;'+fmtCss(TF, TF.size||11)+'" title="'+esc(t('tipDragEdit'))+'">' +
             '<span class="t-dot" style="'+(TF.color ? 'color:'+TF.color+';' : '')+'">•</span>'+esc(t2)+'</div>';
      });
    });
    b += '</td></tr>';
  });
  b += '<tr class="add-row"><td colspan="'+(M+N)+'"><button type="button" class="add-item-trigger">'+esc(t('addRowBtn'))+'</button></td></tr>';
  $('tbody').innerHTML = b;

  /* ---- 工具条状态 ---- */
  $('projName').value = data.name;
  $('startIn').value = data.start;
  $('endIn').value = data.end;
  $('tableWrap').setAttribute('data-view', data.view);
  document.querySelectorAll('.seg-view button').forEach(function(btn){
    btn.classList.toggle('active', btn.dataset.view === data.view);
  });

  renderAll();
  save();
  renderTabs();
}

/* ================= 布局：与表头时间轴像素级对齐 + 自动避让 ================= */
function renderAll(){
  document.querySelectorAll('.item-row').forEach(function(tr){
    layoutRow(tr);
    drawRow(tr);
  });
  drawLinks();
}
function layoutRow(tr){
  var body = tr.querySelector('.row-body');
  var W = body.offsetWidth;
  if(!W) return;
  var bodyRect = body.getBoundingClientRect();
  var table = tr.closest('.plan-table');
  var ths = table.querySelectorAll('thead th.day-head');
  if(!ths.length) return;
  var N = ths.length;
  var lpad = parseFloat(tr.dataset.lpad) || 0;
  var coff = parseFloat(tr.dataset.coff) || 0;

  /* 表头列实际位置作为基准（像素级对齐时间轴，完全兼容每列独立宽度） */
  var lefts = [], widths = [], centers = [];
  Array.prototype.slice.call(ths).forEach(function(th){
    var r = th.getBoundingClientRect();
    var l = r.left - bodyRect.left;
    lefts.push(l);
    widths.push(r.width);
    centers.push(l + r.width/2);
  });
  var cols = buildColumns(parse(data.start), parse(data.end), data.view);

  /* 按每列真实右边界精确绘制列分隔线与行内列宽拖拽手柄 */
  var guidesEl = body.querySelector('.guides');
  if(guidesEl){
    var bgImgs = [], bgPos = [], bgSz = [];
    for(var gi = 0; gi < N - 1; gi++){
      var gx = Math.round(lefts[gi] + widths[gi]) - 1;
      bgImgs.push('linear-gradient(#eceef3,#eceef3)');
      bgPos.push(gx + 'px 0');
      bgSz.push('1px 100%');
    }
    guidesEl.style.backgroundImage = bgImgs.join(',') || 'none';
    guidesEl.style.backgroundPosition = bgPos.join(',');
    guidesEl.style.backgroundSize = bgSz.join(',');
    guidesEl.style.backgroundRepeat = 'no-repeat';
  }
  var todayEl = body.querySelector('.today-col');
  var tIdx = parseInt(body.dataset.tidx, 10);
  if(todayEl && tIdx >= 0 && tIdx < N){
    todayEl.style.left = lefts[tIdx] + 'px';
    todayEl.style.width = widths[tIdx] + 'px';
  }
  Array.prototype.slice.call(body.querySelectorAll('.tcol-resize')).forEach(function(h){
    var ci = +h.dataset.colIdx;
    if(ci >= 0 && ci < N){
      h.style.left = (Math.round(lefts[ci] + widths[ci]) - 5) + 'px';
    }
  });

  function colOf(dateStr){ return colIdxOf(cols, dateStr); }
  /* 列内按日期比例定位：日视图居中、周视图按星期几、月视图按几号 */
  function baseXOf(dateStr, colIdx){
    if(colIdx < 0 || colIdx >= N) colIdx = 0;
    var d = parse(dateStr);
    var w = widths[colIdx] || 120;
    if(data.view === 'day') return centers[colIdx];
    if(data.view === 'week'){
      var di = (d.getDay()+6)%7;
      return lefts[colIdx] + w*(di+0.5)/7;
    }
    var daysIn = new Date(d.getFullYear(), d.getMonth()+1, 0).getDate();
    return lefts[colIdx] + w*((d.getDate()-1)+0.5)/daysIn;
  }

  /* 同日节点（按节点分组）：列内微偏移，宽度保持原有（不再收窄） */
  var offMap = {};   /* nid -> {x: 列内偏移} */
  var labelEls = Array.prototype.slice.call(body.querySelectorAll('.node-lbl'));
  var nodeByDate = {};
  labelEls.forEach(function(el){
    (nodeByDate[el.dataset.date] = nodeByDate[el.dataset.date] || []).push(el.dataset.nid);
  });
  Object.keys(nodeByDate).forEach(function(date){
    var nids = Array.from(new Set(nodeByDate[date]));
    var ci = colOf(date);
    var cw = (ci >= 0 && widths[ci]) ? widths[ci] : 120;
    nids.forEach(function(nid,k){
      offMap[nid] = { x: (nids.length > 1 ? (k-(nids.length-1)/2) * Math.min(cw*0.12, 18) : 0) };
    });
  });

  labelEls.forEach(function(el){
    var o = offMap[el.dataset.nid] || { x:0 };
    var base = baseXOf(el.dataset.date, colOf(el.dataset.date)) + o.x;
    var node = findNode(el.dataset.iid, el.dataset.nid);
    var off = (node && node.lblOff) || {x:0, y:0};
    el.style.left = (base + (off.x||0)) + 'px';
    el.style.top  = (LBL_TOP + coff + (off.y||0)) + 'px';
    el.dataset.ax = base;
    el.dataset.ay = LBL_TOP + coff;
  });

  /* 圆点与标签/任务共用同一 x（修复：图标点跟随时间轴对齐） */
  Array.prototype.slice.call(body.querySelectorAll('.node')).forEach(function(el){
    var o = offMap[el.dataset.nid] || { x:0 };
    var base = baseXOf(el.dataset.date, colOf(el.dataset.date)) + o.x;
    el.style.left = base + 'px';
  });

  Array.prototype.slice.call(body.querySelectorAll('.task-chip')).forEach(function(el){
    var o = offMap[el.dataset.nid] || { x:0 };
    var base = baseXOf(el.dataset.date, colOf(el.dataset.date)) + o.x;
    var tk = +el.dataset.k;
    var node = findNode(el.dataset.iid, el.dataset.nid);
    var off = (node && node.taskOff && node.taskOff[tk]) || {x:0, y:0};
    el.style.left = (base + (off.x||0)) + 'px';
    var step = node ? nodeTaskStep(node) : CHIP_STEP;
    el.style.top  = (CHIP_TOP + tk*step + lpad + coff + (off.y||0)) + 'px';
    el.dataset.ax = base;
    el.dataset.ay = CHIP_TOP + tk*step + lpad + coff;
  });
}

/* ================= 连线绘制 ================= */
function drawRow(tr){
  var body = tr.querySelector('.row-body');
  var svg = body.querySelector('svg.track');
  var W = body.offsetWidth, H = body.offsetHeight;
  if(!W || !H) return;
  var lpad = parseFloat(tr.dataset.lpad) || 0;
  var coff = parseFloat(tr.dataset.coff) || 0;
  svg.setAttribute('viewBox', '0 0 '+W+' '+H);
  var bodyRect = body.getBoundingClientRect();
  var paths = [];

  var dots = Array.prototype.slice.call(body.querySelectorAll('.node-dot')).map(function(dot){
    var r = dot.getBoundingClientRect();
    var n = findNode(dot.parentNode.dataset.iid, dot.parentNode.dataset.nid);
    return { x: r.left - bodyRect.left + r.width/2, y: r.top - bodyRect.top + r.height/2,
             date: dot.parentNode.dataset.date, nid: dot.parentNode.dataset.nid,
             half: nodeSize(n)/2 };
  }).sort(function(a,b){ return a.date < b.date ? -1 : 1; });

  var L = lineOpts();
  var segDash = '';
  if(L.style === 'dashed') segDash = 'stroke-dasharray:7 5;';
  else if(L.style === 'dotted') segDash = 'stroke-dasharray:2 4;';

  for(var i = 1; i < dots.length; i++){
    var x1 = dots[i-1].x, x2 = dots[i].x, y = MAIN_Y+lpad+coff;
    paths.push('<path class="seg" d="M '+x1+' '+y+' L '+x2+' '+y+'" style="stroke:'+L.color+';stroke-width:'+L.width+'px;'+segDash+'"/>');
    if(L.arrow !== 'none'){
      paths.push(arrowHeadSvg(x1, y, x2, y, L.arrow, L.color, L.width));
    }
  }
  if(dots.length){
    var last = dots[dots.length-1];
    paths.push('<path class="seg faint" d="M '+last.x+' '+(MAIN_Y+lpad+coff)+' L '+Math.min(W-8, last.x+36)+' '+(MAIN_Y+lpad+coff)+'"/>');
  }

  Array.prototype.slice.call(body.querySelectorAll('.node-lbl')).forEach(function(lbl){
    var r = lbl.getBoundingClientRect();
    var lx = r.left - bodyRect.left + r.width/2;
    var lBottom = r.top - bodyRect.top + r.height;
    var dot = dots.find(function(d){ return d.nid === lbl.dataset.nid; });
    if(dot){
      paths.push('<path class="stem" d="M '+dot.x+' '+(dot.y-dot.half)+' L '+lx+' '+lBottom+'"/>');
    }
  });

  var chipEls = Array.prototype.slice.call(body.querySelectorAll('.task-chip'));
  var byNid = {};
  chipEls.forEach(function(el){ (byNid[el.dataset.nid] = byNid[el.dataset.nid] || []).push(el); });
  Object.keys(byNid).forEach(function(nid){
    var list = byNid[nid].sort(function(a,b){ return +a.dataset.k - +b.dataset.k; });
    var dot = dots.find(function(d){ return d.nid === nid; });
    if(!dot || list.length === 0) return;
    var r0 = list[0].getBoundingClientRect();
    var cx = r0.left - bodyRect.left + r0.width/2;
    var top0 = r0.top - bodyRect.top;
    paths.push('<path class="stem" d="M '+dot.x+' '+(dot.y+dot.half)+' L '+dot.x+' '+top0+' L '+cx+' '+top0+'"/>');
    for(var k = 1; k < list.length; k++){
      var ra = list[k-1].getBoundingClientRect(), rb = list[k].getBoundingClientRect();
      var x = ra.left - bodyRect.left + ra.width/2;
      paths.push('<path class="stem" d="M '+x+' '+(ra.bottom - bodyRect.top)+' L '+x+' '+(rb.top - bodyRect.top)+'"/>');
    }
  });

  svg.innerHTML = paths.join('');
}

/* ================= 手动连线（节点图标 ↔ 节点图标） ================= */
function linkEnds(){
  var map = {};
  var wrap = $('tableWrap');
  if(!wrap) return map;
  Array.prototype.slice.call(wrap.querySelectorAll('.node')).forEach(function(el){
    var dot = el.querySelector('.node-dot');
    if(!dot) return;
    var r = dot.getBoundingClientRect();
    var n = findNode(el.dataset.iid, el.dataset.nid);
    map[el.dataset.iid + ':' + el.dataset.nid] = {
      x: r.left + r.width/2,
      y: r.top + r.height/2,
      size: nodeSize(n)
    };
  });
  return map;
}
function drawLinks(){
  var wrap = $('tableWrap');
  if(!wrap) return;
  var ov = wrap.querySelector('svg.link-overlay');
  var table = wrap.querySelector('table.plan-table');
  if(!ov || !table) return;
  var wrapRect = wrap.getBoundingClientRect();
  var tableRect = table.getBoundingClientRect();
  ov.style.left = (tableRect.left - wrapRect.left + wrap.scrollLeft) + 'px';
  ov.style.top  = (tableRect.top  - wrapRect.top  + wrap.scrollTop)  + 'px';
  ov.style.width = table.offsetWidth + 'px';
  ov.style.height = table.offsetHeight + 'px';

  var ends = linkEnds();
  var paths = [];
  (data.links||[]).forEach(function(lk){
    var A = ends[(lk.a && lk.a.iid) + ':' + (lk.a && lk.a.nid)];
    var B = ends[(lk.b && lk.b.iid) + ':' + (lk.b && lk.b.nid)];
    if(!A || !B) return;
    var ax = A.x - tableRect.left, ay = A.y - tableRect.top;
    var bx = B.x - tableRect.left, by = B.y - tableRect.top;
    var dx = bx - ax, dy = by - ay;
    var len = Math.sqrt(dx*dx + dy*dy) || 1;
    var ux = dx/len, uy = dy/len;
    var x1 = ax + ux*(A.size/2), y1 = ay + uy*(A.size/2);
    var x2 = bx - ux*(B.size/2), y2 = by - uy*(B.size/2);
    /* 点击热区两端额外内缩，避免粗连线的透明热区覆盖节点图标及其「＋」直连端口 */
    var hitA = Math.max(A.size/2 + 12, 18);
    var hitB = Math.max(B.size/2 + 12, 18);
    if(hitA + hitB + 8 > len){
      hitA = len * 0.35;
      hitB = len * 0.35;
    }
    var hx1 = ax + ux*hitA, hy1 = ay + uy*hitA;
    var hx2 = bx - ux*hitB, hy2 = by - uy*hitB;
    var w = lk.width || 2;
    var style = lk.style || 'solid';
    var dash = style === 'dashed' ? '7 5' : (style === 'dotted' ? '2 4' : '');
    var dashAttr = dash ? 'stroke-dasharray:'+dash+';' : '';
    var d = 'M '+x1.toFixed(2)+' '+y1.toFixed(2)+' L '+x2.toFixed(2)+' '+y2.toFixed(2);
    var dh = 'M '+hx1.toFixed(2)+' '+hy1.toFixed(2)+' L '+hx2.toFixed(2)+' '+hy2.toFixed(2);
    paths.push('<path class="link-vis" data-id="'+esc(lk.id)+'" d="'+d+'" style="stroke:'+MANUAL_LINK_COLOR+';stroke-width:'+w+'px;'+dashAttr+'"/>');
    paths.push('<path class="link-hit" data-id="'+esc(lk.id)+'" d="'+dh+'" style="stroke-width:'+Math.max(w, 12)+'px"/>');
  });
  ov.innerHTML = paths.join('');
}

/* ================= 拖动（标签 / 任务框） ================= */
var dragState = null;
var suppressClick = false;

function startDrag(e, el){
  e.preventDefault();
  var body = el.closest('.row-body');
  var bodyRect = body.getBoundingClientRect();
  var r = el.getBoundingClientRect();
  dragState = {
    el:el, body:body,
    startX:e.clientX, startY:e.clientY,
    elLeft: r.left - bodyRect.left,
    elTop: r.top - bodyRect.top,
    elW: el.offsetWidth,          /* 元素宽度（translateX(-50%) 会平移半宽，计算需补偿） */
    ax: parseFloat(el.dataset.ax), ay: parseFloat(el.dataset.ay),
    iid: el.dataset.iid, nid: el.dataset.nid,
    k: (el.dataset.k !== undefined ? el.dataset.k : null),
    moved:false, snap:snapshot()
  };
  el.classList.add('dragging');
  if(el.setPointerCapture) el.setPointerCapture(e.pointerId);
}
function moveDrag(e){
  if(!dragState) return;
  var s = dragState;
  var dx = e.clientX - s.startX, dy = e.clientY - s.startY;
  if(!s.moved && Math.abs(dx) + Math.abs(dy) > 4) s.moved = true;
  if(s.moved){
    s.el.style.left = (s.elLeft + dx + s.elW/2) + 'px';
    s.el.style.top  = (s.elTop + dy) + 'px';
  }
}
function endDrag(){
  if(!dragState) return;
  var s = dragState;
  s.el.classList.remove('dragging');
  if(s.moved){
    var bodyRect = s.body.getBoundingClientRect();
    var r = s.el.getBoundingClientRect();
    var left = r.left - bodyRect.left, top = r.top - bodyRect.top;
    var offX = left - s.ax + s.elW/2, offY = top - s.ay;
    var node = findNode(s.iid, s.nid);
    if(node){
      commitUndo(s.snap);
      if(s.k !== null && s.k !== undefined){
        node.taskOff = node.taskOff || {};
        node.taskOff[s.k] = { x:offX, y:offY };
      } else {
        node.lblOff = { x:offX, y:offY };
      }
    }
    save();
    renderAll();
    toast(t('tPosMoved'));
    suppressClick = true;
  }
  dragState = null;
}

/* ================= 行拖动排序 ================= */
function moveItem(from, to){
  var items = data.items;
  var R = items.length;
  if(from < 0 || from >= R || to < 0 || to >= R || from === to) return;
  var order = items.map(function(_, i){ return i; });
  var moved = order.splice(from, 1)[0];
  order.splice(to, 0, moved);
  var newIdxOfOld = new Array(R);
  order.forEach(function(oldIdx, newIdx){ newIdxOfOld[oldIdx] = newIdx; });
  data.items = order.map(function(oldIdx){ return items[oldIdx]; });
  var newMerges = [];
  (data.merges||[]).forEach(function(m){
    var newAnchor = newIdxOfOld[m.r];
    if(newAnchor === undefined) return;
    var ok = true;
    for(var k = 0; k < m.rs; k++){
      if(newIdxOfOld[m.r + k] !== newAnchor + k){ ok = false; break; }
    }
    if(ok) newMerges.push({ r:newAnchor, c:m.c, rs:m.rs, cs:m.cs });
  });
  data.merges = newMerges;
  normalizeMerges();
}
function computeRowInsertIndex(clientY){
  var rows = Array.prototype.slice.call(document.querySelectorAll('#tbody tr.item-row'));
  for(var i = 0; i < rows.length; i++){
    var r = rows[i].getBoundingClientRect();
    if(clientY < r.top + r.height/2) return i;
  }
  return rows.length;
}
var rowDragState = null;
function startRowDrag(e, tr){
  e.preventDefault();
  rowDragState = { tr:tr, iid:tr.dataset.iid, startY:e.clientY, lastY:e.clientY, moved:false, snap:snapshot() };
  tr.classList.add('row-dragging');
  if(tr.setPointerCapture) tr.setPointerCapture(e.pointerId);
}
function moveRowDrag(e){
  if(!rowDragState) return;
  rowDragState.moved = true;
  rowDragState.lastY = e.clientY;
  var drop = computeRowInsertIndex(e.clientY);
  document.querySelectorAll('#tbody tr.item-row').forEach(function(tr, i){
    tr.classList.toggle('drop-before', i === drop);
  });
}
function endRowDrag(){
  if(!rowDragState) return;
  var s = rowDragState;
  s.tr.classList.remove('row-dragging');
  document.querySelectorAll('#tbody tr.item-row').forEach(function(tr){ tr.classList.remove('drop-before'); });
  if(s.moved){
    var from = data.items.findIndex(function(x){ return x.id === s.iid; });
    var drop = computeRowInsertIndex(s.lastY);
    var to = (from < drop) ? drop - 1 : drop;
    to = Math.max(0, Math.min(data.items.length - 1, to));
    if(from >= 0 && to !== from){
      commitUndo(s.snap);
      moveItem(from, to);
      save();
      render();
      toast(t('tRowReordered'));
    }
    suppressClick = true;
  }
  rowDragState = null;
}

/* ================= 时间轴：滑动 / 拉长 / 缩放 ================= */
function scrollAxis(dir){
  var w = $('tableWrap');
  w.scrollBy({ left: dir * w.clientWidth * 0.7, behavior:'smooth' });
}
$('scrollL').addEventListener('click', function(){ scrollAxis(-1); });
$('scrollR').addEventListener('click', function(){ scrollAxis(1); });

$('extendWeek').addEventListener('click', function(){
  pushUndo();
  data.end = fmt(addDays(parse(data.end), 7));
  render();
});
$('extendMonth').addEventListener('click', function(){
  pushUndo();
  data.end = fmt(addDays(parse(data.end), 30));
  render();
});

$('fitBtn').addEventListener('click', function(){
  pushUndo();
  var all = [];
  data.items.forEach(function(it){ it.nodes.forEach(function(n){ all.push(n.date); }); });
  if(all.length){
    var sorted = all.slice().sort();
    data.start = fmt(addDays(parse(sorted[0]), -3));
    data.end   = fmt(addDays(parse(sorted[sorted.length-1]), 3));
    toast(t('tFitAll',{n:all.length}));
  } else {
    data.start = todayFmt;
    data.end = fmt(addDays(today, 30));
    toast(t('tFitEmpty'));
  }
  render();
});

/* 右侧手柄：自由拉长 / 缩短时间轴 */
var gripState = null;
var grip = $('stretchGrip');
function placeGrip(){
  var wrap = $('tableWrap');
  grip.style.top = (wrap.getBoundingClientRect().top + 2) + 'px';
}
grip.addEventListener('pointerdown', function(e){
  e.preventDefault();
  gripState = { startX: e.clientX, end: parse(data.end), moved:false, snap:snapshot() };
  grip.classList.add('active');
  if(grip.setPointerCapture) grip.setPointerCapture(e.pointerId);
});
grip.addEventListener('pointermove', function(e){
  if(!gripState) return;
  gripState.moved = true;
  var dx = e.clientX - gripState.startX;
  var colW = { day:92, week:120, month:150 }[data.view] || 120;
  var daysPerCol = data.view === 'day' ? 1 : (data.view === 'week' ? 7 : 30);
  var delta = Math.round(dx / colW) * daysPerCol;
  var newEnd = addDays(gripState.end, delta);
  var minEnd = parse(data.start);
  data.items.forEach(function(it){
    it.nodes.forEach(function(n){ var d = parse(n.date); if(d > minEnd) minEnd = d; });
  });
  if(newEnd < minEnd) newEnd = minEnd;
  data.end = fmt(newEnd);
  render();
});
document.addEventListener('pointerup', function(){
  if(gripState){
    if(gripState.moved) commitUndo(gripState.snap);
    gripState = null; grip.classList.remove('active');
  }
});
document.addEventListener('pointercancel', function(){
  if(gripState){ gripState = null; grip.classList.remove('active'); }
});

/* ===== 行高拖拽：在基础自动高度上追加，最小不低于自动高度 ===== */
var rowResizeState = null;
function startRowResize(e, tr){
  e.preventDefault();
  var body = tr.querySelector('.row-body');
  rowResizeState = { tr:tr, startY:e.clientY, baseH: parseFloat(body.style.height) || body.offsetHeight, moved:false, snap:snapshot() };
  tr.querySelectorAll('.row-grip, .row-resize').forEach(function(g){ g.classList.add('active'); });
  if(tr.setPointerCapture) tr.setPointerCapture(e.pointerId);
}
function moveRowResize(e){
  if(!rowResizeState) return;
  var s = rowResizeState;
  s.moved = true;
  var dy = e.clientY - s.startY;
  var it = findItem(s.tr.dataset.iid);
  var auto = itemAutoH(it);
  var h = Math.max(auto, Math.round(s.baseH + dy));
  it.hAdj = h - auto;
  var coff = rowCoff(it, h);
  s.tr.dataset.coff = coff;
  var lpad = parseFloat(s.tr.dataset.lpad) || 0;
  var body = s.tr.querySelector('.row-body');
  body.style.height = h + 'px';
  body.querySelector('.timeline-track').style.top = (38+lpad+coff) + 'px';
  body.querySelectorAll('.node').forEach(function(el){
    var node = findNode(el.dataset.iid, el.dataset.nid);
    el.style.top = (MAIN_Y - nodeSize(node)/2 + lpad + coff) + 'px';
  });
  layoutRow(s.tr);
  drawRow(s.tr);
  drawLinks();
}
function endRowResize(){
  if(!rowResizeState) return;
  var s = rowResizeState;
  var body = s.tr.querySelector('.row-body');
  var it = findItem(s.tr.dataset.iid);
  if(it){
    if(s.moved) commitUndo(s.snap);
    it.hAdj = Math.max(0, Math.round(body.offsetHeight - itemAutoH(it)));
    save();
  }
  s.tr.querySelectorAll('.row-grip, .row-resize').forEach(function(g){ g.classList.remove('active'); });
  rowResizeState = null;
  render();
  toast(t('tRowResized'));
}
/* ===== 左侧列宽拖拽（每列独立） ===== */
var colResizeState = null;
function startColResize(e, handle){
  e.preventDefault();
  var c = +handle.dataset.c;
  colResizeState = { c:c, startX:e.clientX, w:data.leftCols[c].w, moved:false, snap:snapshot() };
  handle.classList.add('active');
  document.querySelectorAll('.col-resize').forEach(function(h){ h.classList.add('active'); });
  if(handle.setPointerCapture) handle.setPointerCapture(e.pointerId);
}
function moveColResize(e){
  if(!colResizeState) return;
  colResizeState.moved = true;
  var dx = e.clientX - colResizeState.startX;
  var w = Math.max(120, Math.min(420, colResizeState.w + dx));
  data.leftCols[colResizeState.c].w = Math.round(w);
  applyLeftWidths();
  renderAll();
}
function endColResize(){
  if(!colResizeState) return;
  if(colResizeState.moved) commitUndo(colResizeState.snap);
  save();
  document.querySelectorAll('.col-resize').forEach(function(h){ h.classList.remove('active'); });
  colResizeState = null;
  render();
  toast(t('tLeftColResized'));
}
/* ===== 时间轴列宽拖拽（表头及表格内任意行均可直接拖拽调宽） ===== */
var tcolResizeState = null;
function startTColResize(e, handle){
  e.preventDefault();
  var key = handle.dataset.colKey;
  var idx = +handle.dataset.colIdx;
  var th = document.querySelector('thead th.day-head[data-col-idx="'+idx+'"]');
  var startW = th ? th.getBoundingClientRect().width : Math.round(baseColWOf(data.view) * (data.colScale || 1));
  tcolResizeState = { key:key, idx:idx, startX:e.clientX, w:startW, moved:false, snap:snapshot() };
  document.querySelectorAll('.tcol-resize[data-col-idx="'+idx+'"]').forEach(function(h){ h.classList.add('active'); });
  if(handle.setPointerCapture) handle.setPointerCapture(e.pointerId);
}
function moveTColResize(e){
  if(!tcolResizeState) return;
  var s = tcolResizeState;
  var dx = e.clientX - s.startX;
  if(!s.moved && Math.abs(dx) > 2) s.moved = true;
  var w = Math.max(56, Math.min(480, Math.round(s.w + dx)));
  data.colWidths = data.colWidths || {};
  data.colWidths[s.key] = w;
  var th = document.querySelector('thead th.day-head[data-col-idx="'+s.idx+'"]');
  if(th){
    th.style.width = th.style.minWidth = th.style.maxWidth = w + 'px';
  }
  renderAll();
}
function endTColResize(){
  if(!tcolResizeState) return;
  var s = tcolResizeState;
  document.querySelectorAll('.tcol-resize[data-col-idx="'+s.idx+'"]').forEach(function(h){ h.classList.remove('active'); });
  if(s.moved){
    commitUndo(s.snap);
    save();
    render();
    var finalW = (data.colWidths && data.colWidths[s.key]) || Math.round(s.w);
    toast(t('tColResized',{w:finalW}));
    suppressClick = true;
  }
  tcolResizeState = null;
}
/* 按当前 leftCols 宽度刷新左侧表头与单元格（拖拽时实时用） */
function applyLeftWidths(){
  var M = data.leftCols.length;
  var loff = leftOffsets();
  var hc = headerCoverage();
  for(var c = 0; c < M; c++){
    if(hc[c] !== c) continue;
    var cs = data.leftCols[c].cs || 1;
    var w = 0, k; for(k = c; k < c+cs; k++) w += data.leftCols[k].w;
    var th = document.querySelector('thead th.lc-h[data-c="'+c+'"]');
    if(!th) continue;
    th.style.width = th.style.minWidth = th.style.maxWidth = w + 'px';
    th.style.left = loff[c] + 'px';
    for(var hk0 = c; hk0 < c+cs; hk0++){
      var bx0 = 0, bk0; for(bk0 = c; bk0 <= hk0; bk0++) bx0 += data.leftCols[bk0].w;
      var hh = th.querySelector('.col-resize[data-c="'+hk0+'"]');
      if(hh) hh.style.left = (bx0 - 9) + 'px';
    }
  }
  var cov = leftCoverage();
  data.items.forEach(function(it, r){
    for(var c = 0; c < M; c++){
      var m = cov[r+','+c];
      if(m && !(m.r === r && m.c === c)) continue;
      var cs = m ? m.cs : 1;
      var w = 0, k; for(k = c; k < c+cs; k++) w += data.leftCols[k].w;
      var th = document.querySelector('th.item-col[data-r="'+r+'"][data-c="'+c+'"]');
      if(!th) continue;
      th.style.width = th.style.minWidth = th.style.maxWidth = w + 'px';
      th.style.left = loff[c] + 'px';
      for(var hk1 = c; hk1 < c+cs; hk1++){
        var bx1 = 0, bk1; for(bk1 = c; bk1 <= hk1; bk1++) bx1 += data.leftCols[bk1].w;
        var ch = th.querySelector('.col-resize[data-c="'+hk1+'"]');
        if(ch) ch.style.left = (bx1 - 9) + 'px';
      }
    }
  });
}
document.addEventListener('pointermove', function(e){
  if(rowDragState) moveRowDrag(e);
  else if(rowResizeState) moveRowResize(e);
  else if(colResizeState) moveColResize(e);
  else if(tcolResizeState) moveTColResize(e);
});
document.addEventListener('pointerup', function(){
  if(rowDragState) endRowDrag();
  else if(rowResizeState) endRowResize();
  else if(colResizeState) endColResize();
  else if(tcolResizeState) endTColResize();
});
document.addEventListener('pointercancel', function(){
  if(rowDragState) endRowDrag();
  else if(rowResizeState) endRowResize();
  else if(colResizeState) endColResize();
  else if(tcolResizeState) endTColResize();
});

function scrollToNode(nid){
  var el = document.querySelector('.node[data-nid="'+nid+'"]');
  if(el) el.scrollIntoView({ inline:'center', block:'nearest' });
}
/* ================= 节点编辑 ================= */
var nodeState = { mode:'add', iid:null, nid:null };

function sizeOptions(sel, cur){
  sel.innerHTML = FMT_SIZES.map(function(s){
    return '<option value="'+s+'"'+(s===cur?' selected':'')+'>'+s+'</option>';
  }).join('');
}
function shapeOptions(sel, cur){
  var map = (I18N[curLang] && I18N[curLang].shapes) || I18N.zh.shapes;
  sel.innerHTML = NODE_SHAPES.map(function(sh){
    return '<option value="'+sh.id+'"'+(sh.id===cur?' selected':'')+'>'+(map[sh.id]||sh.label)+'</option>';
  }).join('');
}
function nodeSizeOptions(sel, cur){
  sel.innerHTML = NODE_SIZE_OPTIONS.map(function(s){
    return '<option value="'+s+'"'+(s===cur?' selected':'')+'>'+s+'px</option>';
  }).join('');
}
/* 把格式载入工具条（null = 默认值） */
function loadFmtToBar(c, b, i, s, fmt, defColor){
  c.value = (fmt && fmt.color) || defColor;
  b.classList.toggle('on', !!(fmt && fmt.bold));
  i.classList.toggle('on', !!(fmt && fmt.italic));
  s.value = (fmt && fmt.size) || 11;
}
/* 从工具条读取格式（只记录与默认不同的项） */
function readFmtFrom(c, b, i, s, defColor){
  var f = {};
  if(c.value.toLowerCase() !== defColor) f.color = c.value;
  if(b.classList.contains('on')) f.bold = true;
  if(i.classList.contains('on')) f.italic = true;
  if(+s.value !== 11) f.size = +s.value;
  return f;
}

function addTaskRow(val, fmt){
  var box = $('ndTasks');
  var row = document.createElement('div');
  row.className = 'task-row';
  row.innerHTML = '<span class="tdot">•</span>' +
                  '<input class="task-input" value="'+esc(val)+'" placeholder="'+esc(t('taskPh'))+'">' +
                  '<input type="color" class="task-c" title="'+esc(t('lnColorLbl'))+'" value="#20242e">' +
                  '<button type="button" class="task-b" title="B">B</button>' +
                  '<button type="button" class="task-i" title="I">I</button>' +
                  '<select class="task-s" title="px"></select>' +
                  '<button type="button" class="icon-btn del-task" title="'+esc(t('delBtn'))+'">✕</button>';
  var c = row.querySelector('.task-c'), b = row.querySelector('.task-b');
  var i = row.querySelector('.task-i'), s = row.querySelector('.task-s');
  sizeOptions(s, (fmt && fmt.size) || 11);
  c.value = (fmt && fmt.color) || '#20242e';
  b.classList.toggle('on', !!(fmt && fmt.bold));
  i.classList.toggle('on', !!(fmt && fmt.italic));
  b.addEventListener('click', function(){ b.classList.toggle('on'); });
  i.addEventListener('click', function(){ i.classList.toggle('on'); });
  row.querySelector('.del-task').addEventListener('click', function(){ row.remove(); });
  box.appendChild(row);
  return row;
}
function readTaskRowFmt(row){
  return readFmtFrom(row.querySelector('.task-c'), row.querySelector('.task-b'),
                     row.querySelector('.task-i'), row.querySelector('.task-s'), '#20242e');
}
function renderTaskInputs(tasks, tFmt){
  $('ndTasks').innerHTML = '';
  var list = (tasks && tasks.length) ? tasks.slice() : [''];
  list.forEach(function(t, tk){ addTaskRow(t, tFmt && tFmt[tk]); });
}
function openNodeModal(mode, iid, nid, colStart, colEnd){
  nodeState = { mode:mode, iid:iid, nid:nid };
  var item = data.items.find(function(x){ return x.id===iid; });
  $('ndItem').textContent = item ? item.name : '—';
  $('nodeModalTitle').textContent = (mode==='edit') ? t('nodeEditTitle') : t('nodeAddTitle');
  if(mode === 'edit' && item){
    var node = item.nodes.find(function(n){ return n.id===nid; });
    $('ndTitle').value = node.title;
    $('ndDate').value = node.date;
    $('ndDelete').classList.remove('hidden');
    loadFmtToBar($('lblFmtC'), $('lblFmtB'), $('lblFmtI'), $('lblFmtS'), node.fmt, '#3c4f9a');
    $('ndShape').value = nodeShape(node);
    $('ndShapeColor').value = nodeColor(node);
    $('ndSize').value = String(nodeSize(node));
    renderTaskInputs(node.tasks, node.tFmt);
  } else {
    var date = colStart;
    if(colEnd && colStart !== colEnd){
      var s = parse(colStart), e = parse(colEnd);
      if(today >= s && today <= e) date = todayFmt;
    }
    $('ndTitle').value = '';
    $('ndDate').value = date;
    $('ndDelete').classList.add('hidden');
    loadFmtToBar($('lblFmtC'), $('lblFmtB'), $('lblFmtI'), $('lblFmtS'), null, '#3c4f9a');
    $('ndShape').value = 'circle';
    $('ndShapeColor').value = NODE_COLOR_DEFAULT;
    $('ndSize').value = String(NODE_SIZE_DEFAULT);
    renderTaskInputs([]);
  }
  $('nodeModal').classList.remove('hidden');
  centerModal('nodeModal');
  updateNdWeek();
  $('ndTitle').focus();
}
function hideModal(id){ $(id).classList.add('hidden'); }
function updateNdWeek(){
  var v = $('ndDate').value;
  if(!v){ $('ndWeek').textContent = ''; return; }
  $('ndWeek').textContent = t('weekFmt', { w: isoWeek(parse(v)) });
}

/* 节点编辑弹窗：居中定位（打开时调用） */
function centerModal(id){
  var mask = $(id);
  var modal = mask.querySelector('.modal');
  if(!modal) return;
  modal.style.left = Math.max(0, Math.round((mask.clientWidth - modal.offsetWidth) / 2)) + 'px';
  modal.style.top  = Math.max(0, Math.round(mask.clientHeight * 0.08)) + 'px';
}
/* 节点编辑弹窗：按住标题栏拖动窗口 */
function enableModalDrag(id){
  var mask = $(id);
  var modal = mask.querySelector('.modal');
  var head = modal.querySelector('h3');
  head.addEventListener('mousedown', function(e){
    if(e.target.closest('input,button,select,textarea,a')) return;
    var sx = e.clientX, sy = e.clientY;
    var ox = modal.offsetLeft, oy = modal.offsetTop;
    var bw = mask.clientWidth, bh = mask.clientHeight;
    function mv(ev){
      var nx = ox + (ev.clientX - sx);
      var ny = oy + (ev.clientY - sy);
      nx = Math.max(60 - modal.offsetWidth, Math.min(nx, bw - 60));
      ny = Math.max(0, Math.min(ny, bh - 40));
      modal.style.left = nx + 'px';
      modal.style.top  = ny + 'px';
    }
    function up(){
      document.removeEventListener('mousemove', mv);
      document.removeEventListener('mouseup', up);
      /* 延迟移除：避免拖动结束后释放到遮罩上时误触发“点击关闭” */
      setTimeout(function(){ document.body.classList.remove('modal-dragging'); }, 0);
    }
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
    document.body.classList.add('modal-dragging');
    e.preventDefault();
  });
}
enableModalDrag('nodeModal');

sizeOptions($('lblFmtS'), 11);
shapeOptions($('ndShape'), 'circle');
nodeSizeOptions($('ndSize'), NODE_SIZE_DEFAULT);
$('lblFmtB').addEventListener('click', function(){ this.classList.toggle('on'); });
$('lblFmtI').addEventListener('click', function(){ this.classList.toggle('on'); });
$('lblFmtX').addEventListener('click', function(){
  loadFmtToBar($('lblFmtC'), $('lblFmtB'), $('lblFmtI'), $('lblFmtS'), null, '#3c4f9a');
});
$('ndShapeX').addEventListener('click', function(){
  $('ndShape').value = 'circle';
  $('ndShapeColor').value = NODE_COLOR_DEFAULT;
  $('ndSize').value = String(NODE_SIZE_DEFAULT);
});
$('ndAddTask').addEventListener('click', function(){ addTaskRow(''); });
$('ndCancel').addEventListener('click', function(){ hideModal('nodeModal'); });
$('ndDate').addEventListener('input', updateNdWeek);
$('ndDate').addEventListener('change', updateNdWeek);
$('ndSave').addEventListener('click', function(){
  var title = $('ndTitle').value.trim();
  var date  = $('ndDate').value;
  if(!date){ toast(t('tSelectDate')); return; }
  var tasks = Array.prototype.slice.call($('ndTasks').querySelectorAll('.task-input'))
              .map(function(i){ return i.value.trim(); }).filter(Boolean);
  var fmt = readFmtFrom($('lblFmtC'), $('lblFmtB'), $('lblFmtI'), $('lblFmtS'), '#3c4f9a');
  var shape = $('ndShape').value || 'circle';
  var color = $('ndShapeColor').value || NODE_COLOR_DEFAULT;
  var size  = parseInt($('ndSize').value, 10) || NODE_SIZE_DEFAULT;
  var tFmt = {};
  Array.prototype.slice.call($('ndTasks').querySelectorAll('.task-row')).forEach(function(row, tk){
    var f = readTaskRowFmt(row);
    if(!fmtEmpty(f)) tFmt[tk] = f;
  });
  var item = data.items.find(function(x){ return x.id===nodeState.iid; });
  if(!item){ toast(t('tNoItem')); return; }
  pushUndo();
  var nid = null;
  if(nodeState.mode === 'edit'){
    var n = item.nodes.find(function(x){ return x.id===nodeState.nid; });
    if(n){
      n.title = title || '未命名节点'; n.date = date; n.tasks = tasks; nid = n.id;
      if(fmtEmpty(fmt)) delete n.fmt; else n.fmt = fmt;
      if(Object.keys(tFmt).length) n.tFmt = tFmt; else delete n.tFmt;
      if(shape !== 'circle') n.shape = shape; else delete n.shape;
      if(color.toLowerCase() !== NODE_COLOR_DEFAULT) n.color = color; else delete n.color;
      if(size !== NODE_SIZE_DEFAULT) n.size = size; else delete n.size;
    }
  } else {
    var nn = { id:uid(), date:date, title:(title || '未命名节点'), tasks:tasks };
    if(!fmtEmpty(fmt)) nn.fmt = fmt;
    if(Object.keys(tFmt).length) nn.tFmt = tFmt;
    if(shape !== 'circle') nn.shape = shape;
    if(color.toLowerCase() !== NODE_COLOR_DEFAULT) nn.color = color;
    if(size !== NODE_SIZE_DEFAULT) nn.size = size;
    item.nodes.push(nn);
    nid = nn.id;
  }
  /* 自动扩展时间轴，确保节点始终可见 */
  if(parse(date) < parse(data.start)) data.start = date;
  if(parse(date) > parse(data.end))   data.end   = date;
  hideModal('nodeModal');
  render();
  scrollToNode(nid);
});
$('ndDelete').addEventListener('click', function(){
  var item = data.items.find(function(x){ return x.id===nodeState.iid; });
  if(item){
    pushUndo();
    item.nodes = item.nodes.filter(function(n){ return n.id !== nodeState.nid; });
    data.links = (data.links||[]).filter(function(lk){
      return !(lk.a && lk.a.nid === nodeState.nid) && !(lk.b && lk.b.nid === nodeState.nid);
    });
    toast(t('tNodeDeleted'));
  }
  hideModal('nodeModal');
  render();
});

/* ================= 事项 ================= */
function showItemModal(){
  $('itName').value = '';
  $('itemModal').classList.remove('hidden');
  $('itName').focus();
}
function makeItem(name){
  name = name || '新事项';
  return { id:uid(), name:name,
    cells: data.leftCols.map(function(c, ci){ return { text: ci === 0 ? name : '' }; }),
    nodes:[] };
}
function addRowAfter(rIdx){
  var R = data.items.length;
  if(R === 0){ rIdx = -1; }
  else if(rIdx < 0 || rIdx >= R){ rIdx = R - 1; }
  /* 若目标行处于合并块内，则整行插入到该合并块下方，避免破坏合并 */
  var hi = rIdx;
  (data.merges||[]).forEach(function(m){
    if(m.r <= rIdx && rIdx < m.r + m.rs){ hi = Math.max(hi, m.r + m.rs - 1); }
  });
  var P = hi + 1;
  pushUndo();
  data.items.splice(P, 0, makeItem('新事项'));
  (data.merges||[]).forEach(function(m){
    if(m.r >= P){ m.r++; }
    else if(m.r + m.rs > P){ m.rs++; }
  });
  normalizeMerges(); save(); render();
  toast(t('tRowInserted'));
}
$('itSave').addEventListener('click', function(){
  var name = $('itName').value.trim();
  if(!name){ toast(t('tEnterItem')); return; }
  pushUndo();
  data.items.push(makeItem(name));
  hideModal('itemModal');
  render();
});
$('itCancel').addEventListener('click', function(){ hideModal('itemModal'); });

/* ================= 左侧列操作：加列 / 删列 / 列名编辑 ================= */
function addLeftColumn(){
  pushUndo();
  var c = data.leftCols.length;
  data.leftCols.push({ label:'新列', w:160 });
  data.items.forEach(function(it){ it.cells.push({ text:'' }); });
  normalizeHeaderSpans(); normalizeMerges(); save(); render();
  toast(t('tColAdded'));
}
function removeLeftColumn(c){
  if(data.leftCols.length <= 1){ toast(t('tKeepOneCol')); return; }
  pushUndo();
  /* 表头跨度调整（删除前按旧索引） */
  var hc = headerCoverage();
  var anc = hc[c];
  if(anc !== undefined){
    data.leftCols[anc].cs = Math.max(1, (data.leftCols[anc].cs || 1) - 1);
  }
  data.leftCols.splice(c, 1);
  data.items.forEach(function(it){ it.cells.splice(c, 1); });
  normalizeHeaderSpans();
  data.merges.forEach(function(m){
    if(m.c === c){ m._drop = true; }
    else if(m.c > c){ m.c--; }
    else if(c < m.c + m.cs){ m.cs--; }
  });
  data.merges = data.merges.filter(function(m){ return !m._drop; });
  normalizeMerges(); save(); render();
  toast(t('tColDeleted'));
}
/* ================= 列标题编辑：文字 + 格式 + 左右合并 ================= */
var headState = null; /* {c} 表头锚点列 */
function openHeadEditor(c){
  var hc = headerCoverage();
  c = hc[c] !== undefined ? hc[c] : c;
  headState = { c:c };
  var col = data.leftCols[c];
  $('hdText').value = col.label || '';
  loadFmtToBar($('hdFmtC'), $('hdFmtB'), $('hdFmtI'), $('hdFmtS'), col.fmt, '#3f4a68');
  var cs = col.cs || 1, M = data.leftCols.length;
  var cov = headerCoverage();
  $('hdMergeL').disabled = !(c > 0 && cov[c-1] === c-1);
  $('hdMergeR').disabled = !(c + cs < M && cov[c+cs] === c+cs);
  $('hdSplit').classList.toggle('hidden', !(cs > 1));
  $('headModal').classList.remove('hidden');
  $('hdText').focus();
}
function headMergeLeft(){
  if(!headState) return;
  var c = headState.c;
  if(c <= 0) return;
  pushUndo();
  data.leftCols[c-1].cs = (data.leftCols[c-1].cs || 1) + 1;
  normalizeHeaderSpans(); save(); render();
  openHeadEditor(c-1);
  toast(t('tHeadMergeL'));
}
function headMergeRight(){
  if(!headState) return;
  var c = headState.c;
  pushUndo();
  data.leftCols[c].cs = (data.leftCols[c].cs || 1) + 1;
  normalizeHeaderSpans(); save(); render();
  openHeadEditor(c);
  toast(t('tHeadMergeR'));
}
function headSplit(){
  if(!headState) return;
  var c = headState.c;
  pushUndo();
  data.leftCols[c].cs = 1;
  normalizeHeaderSpans(); save(); render();
  openHeadEditor(c);
  toast(t('tHeadSplit'));
}
sizeOptions($('hdFmtS'), 12);
$('hdFmtB').addEventListener('click', function(){ this.classList.toggle('on'); });
$('hdFmtI').addEventListener('click', function(){ this.classList.toggle('on'); });
$('hdFmtX').addEventListener('click', function(){
  loadFmtToBar($('hdFmtC'), $('hdFmtB'), $('hdFmtI'), $('hdFmtS'), null, '#3f4a68');
});
$('hdMergeL').addEventListener('click', headMergeLeft);
$('hdMergeR').addEventListener('click', headMergeRight);
$('hdSplit').addEventListener('click', headSplit);
$('hdCancel').addEventListener('click', function(){ hideModal('headModal'); });
$('hdSave').addEventListener('click', function(){
  if(!headState) return;
  var col = data.leftCols[headState.c];
  pushUndo();
  col.label = $('hdText').value;
  var f = readFmtFrom($('hdFmtC'), $('hdFmtB'), $('hdFmtI'), $('hdFmtS'), '#3f4a68');
  if(fmtEmpty(f)) delete col.fmt; else col.fmt = f;
  save(); hideModal('headModal'); render();
  toast(t('tHeadSaved'));
});

/* ================= 单元格编辑：文本 + 格式 + 合并/拆分 ================= */
var cellState = null; /* {r, c} 锚点坐标 */
function openCellEditor(r, c){
  var m = leftCoverage()[r+','+c];
  if(m){ r = m.r; c = m.c; }
  cellState = { r:r, c:c };
  var cell = leftCell(data.items[r], c);
  $('clText').value = cell.text || '';
  loadFmtToBar($('clFmtC'), $('clFmtB'), $('clFmtI'), $('clFmtS'), cell.fmt, '#252b3b');
  /* 合并按钮可用性 */
  var cov = leftCoverage();
  var cur = cov[r+','+c];
  var isAnchor = cur && cur.r === r && cur.c === c;
  var R = data.items.length, M = data.leftCols.length;
  var canD = isAnchor
    ? (r + cur.rs < R && !cov[(r+cur.rs)+','+c])
    : (r + 1 < R && !cov[(r+1)+','+c]);
  var canR = isAnchor
    ? (c + cur.cs < M && !cov[r+','+(c+cur.cs)])
    : (c + 1 < M && !cov[r+','+(c+1)]);
  var canU = r > 0 && !cov[(r-1)+','+c];
  var canL = c > 0 && !cov[r+','+(c-1)];
  $('clMergeU').disabled = !canU;
  $('clMergeD').disabled = !canD;
  $('clMergeL').disabled = !canL;
  $('clMergeR').disabled = !canR;
  $('clSplit').classList.toggle('hidden', !isAnchor);
  $('cellModal').classList.remove('hidden');
  $('clText').focus();
}
function mergeCellDown(){
  if(!cellState) return;
  var s = cellState;
  pushUndo();
  var cov = leftCoverage();
  var m = cov[s.r+','+s.c];
  if(m && m.r === s.r && m.c === s.c){ m.rs++; }
  else { data.merges.push({ r:s.r, c:s.c, rs:2, cs:1 }); }
  normalizeMerges(); save(); render();
  openCellEditor(s.r, s.c);
  toast(t('tMergeD'));
}
function mergeCellRight(){
  if(!cellState) return;
  var s = cellState;
  pushUndo();
  var cov = leftCoverage();
  var m = cov[s.r+','+s.c];
  if(m && m.r === s.r && m.c === s.c){ m.cs++; }
  else { data.merges.push({ r:s.r, c:s.c, rs:1, cs:2 }); }
  normalizeMerges(); save(); render();
  openCellEditor(s.r, s.c);
  toast(t('tMergeR'));
}
function mergeCellUp(){
  if(!cellState) return;
  var s = cellState;
  var cov = leftCoverage();
  var m = cov[s.r+','+s.c];
  var anchorR = (m && m.r === s.r && m.c === s.c) ? m.r - 1 : s.r - 1;
  var anchorC = s.c;
  if(anchorR < 0){ toast(t('tFirstRow')); return; }
  if(cov[anchorR+','+anchorC]){ toast(t('tUpperMerged')); return; }
  pushUndo();
  if(m && m.r === s.r && m.c === s.c){ m.r = anchorR; m.rs++; }
  else { data.merges.push({ r:anchorR, c:anchorC, rs:2, cs:1 }); }
  normalizeMerges(); save(); render();
  openCellEditor(anchorR, anchorC);
  toast(t('tMergeU'));
}
function mergeCellLeft(){
  if(!cellState) return;
  var s = cellState;
  var cov = leftCoverage();
  var m = cov[s.r+','+s.c];
  var anchorR = s.r;
  var anchorC = (m && m.r === s.r && m.c === s.c) ? m.c - 1 : s.c - 1;
  if(anchorC < 0){ toast(t('tFirstCol')); return; }
  if(cov[anchorR+','+anchorC]){ toast(t('tLeftMerged')); return; }
  pushUndo();
  if(m && m.r === s.r && m.c === s.c){ m.c = anchorC; m.cs++; }
  else { data.merges.push({ r:anchorR, c:anchorC, rs:1, cs:2 }); }
  normalizeMerges(); save(); render();
  openCellEditor(anchorR, anchorC);
  toast(t('tMergeL'));
}
function splitCell(){
  if(!cellState) return;
  var s = cellState;
  var cov = leftCoverage();
  var m = cov[s.r+','+s.c];
  if(m && m.r === s.r && m.c === s.c){
    pushUndo();
    data.merges = data.merges.filter(function(x){ return x !== m; });
    normalizeMerges(); save(); render();
    openCellEditor(s.r, s.c);
    toast(t('tCellSplit'));
  }
}
sizeOptions($('clFmtS'), 14);
$('clFmtB').addEventListener('click', function(){ this.classList.toggle('on'); });
$('clFmtI').addEventListener('click', function(){ this.classList.toggle('on'); });
$('clFmtX').addEventListener('click', function(){
  loadFmtToBar($('clFmtC'), $('clFmtB'), $('clFmtI'), $('clFmtS'), null, '#252b3b');
});
$('clMergeU').addEventListener('click', mergeCellUp);
$('clMergeD').addEventListener('click', mergeCellDown);
$('clMergeL').addEventListener('click', mergeCellLeft);
$('clMergeR').addEventListener('click', mergeCellRight);
$('clSplit').addEventListener('click', splitCell);
$('clCancel').addEventListener('click', function(){ hideModal('cellModal'); });
$('clSave').addEventListener('click', function(){
  if(!cellState) return;
  var s = cellState;
  var it = data.items[s.r];
  var cell = leftCell(it, s.c);
  pushUndo();
  cell.text = $('clText').value;
  var f = readFmtFrom($('clFmtC'), $('clFmtB'), $('clFmtI'), $('clFmtS'), '#252b3b');
  if(fmtEmpty(f)) delete cell.fmt; else cell.fmt = f;
  if(s.c === 0) it.name = cell.text || '未命名';
  save(); hideModal('cellModal'); render();
  toast(t('tCellSaved'));
});

function delItem(iid){
  var item = data.items.find(function(x){ return x.id===iid; });
  if(!item) return;
  if(confirm(t('cDelItem',{name:item.name,n:item.nodes.length}))){
    pushUndo();
    var idx = data.items.indexOf(item);
    data.items = data.items.filter(function(x){ return x.id !== iid; });
    data.links = (data.links||[]).filter(function(lk){
      return !(lk.a && lk.a.iid === iid) && !(lk.b && lk.b.iid === iid);
    });
    data.merges.forEach(function(m){
      if(m.r === idx){ m._drop = true; }
      else if(m.r > idx){ m.r--; }
      else if(idx < m.r + m.rs){ m.rs--; }
    });
    data.merges = data.merges.filter(function(m){ return !m._drop; });
    normalizeMerges();
    render();
  }
}

/* ================= 表格事件（委托） ================= */
$('tableWrap').addEventListener('pointerdown', function(e){
  if(suppressClick){ suppressClick = false; return; }
  if(e.target.closest('.node-link-port')) return;
  if(linkMode) return;
  var rd = e.target.closest('.row-drag');
  if(rd && e.button === 0){ startRowDrag(e, rd.closest('.item-row')); return; }
  var rr = e.target.closest('.row-resize, .row-grip');
  if(rr && e.button === 0){ startRowResize(e, rr.closest('.item-row')); return; }
  var cr = e.target.closest('.col-resize');
  if(cr && e.button === 0){ startColResize(e, cr); return; }
  var tcr = e.target.closest('.tcol-resize');
  if(tcr && e.button === 0){ startTColResize(e, tcr); return; }
  var t = e.target.closest('.node-lbl, .task-chip');
  if(t && e.button === 0) startDrag(e, t);
});
$('tableWrap').addEventListener('pointermove', function(e){
  moveDrag(e);
  if(linkMode && linkStart) updateLinkPreview(e.clientX, e.clientY);
});
document.addEventListener('pointerup', endDrag);
document.addEventListener('pointercancel', endDrag);

$('tableWrap').addEventListener('click', function(e){
  if(suppressClick){ suppressClick = false; return; }
  /* 表格内直接点击节点右侧「＋」端口或 Shift+点击节点，直接启动/完成手动连线 */
  var port = e.target.closest('.node-link-port');
  if(port){
    e.stopPropagation();
    startDirectLink(port.dataset.iid, port.dataset.nid);
    return;
  }
  if(linkMode){
    var nd = e.target.closest('.node');
    if(nd){ e.stopPropagation(); handleLinkNodeClick(nd.dataset.iid, nd.dataset.nid); return; }
    if(e.target.closest('td.row-body')){
      setLinkMode(false);
      toast(t('tLinkCancelled'));
    }
    return;
  }
  if(e.target.closest('.row-resize, .row-grip, .col-resize, .tcol-resize')) return;
  var lcAdd = e.target.closest('.lc-add');
  if(lcAdd){ addLeftColumn(); return; }
  var lcDel = e.target.closest('.lc-del');
  if(lcDel){ removeLeftColumn(+lcDel.dataset.c); return; }
  var rowAdd = e.target.closest('.row-add');
  if(rowAdd){ addRowAfter(+rowAdd.dataset.r); return; }
  var hitNode = e.target.closest('.node');
  if(hitNode && e.shiftKey){
    e.stopPropagation();
    startDirectLink(hitNode.dataset.iid, hitNode.dataset.nid);
    return;
  }
  var hit = e.target.closest('.node-lbl, .node, .task-chip');
  if(hit){
    e.stopPropagation();
    openNodeModal('edit', hit.dataset.iid, hit.dataset.nid);
    return;
  }
  var body = e.target.closest('td.row-body');
  if(body){
    var cols = buildColumns(parse(data.start), parse(data.end), data.view);
    var ths = $('thead').querySelectorAll('th.day-head');
    var idx = cols.length - 1;
    for(var ti = 0; ti < ths.length; ti++){
      var trc = ths[ti].getBoundingClientRect();
      if(e.clientX >= trc.left && e.clientX <= trc.right){ idx = ti; break; }
      if(e.clientX < trc.left){ idx = Math.max(0, ti - 1); break; }
    }
    idx = Math.max(0, Math.min(cols.length-1, idx));
    var c = cols[idx];
    openNodeModal('add', body.dataset.iid, null, fmt(c.date), colEnd(c));
    return;
  }
  var del = e.target.closest('.del-item');
  if(del){ delItem(del.dataset.iid); return; }
  var add = e.target.closest('.add-item-trigger');
  if(add){ showItemModal(); return; }
});
$('tableWrap').addEventListener('dblclick', function(e){
  if(e.target.closest('.col-resize, .tcol-resize')) return;
  var cell = e.target.closest('th.item-col');
  if(cell){ openCellEditor(+cell.dataset.r, +cell.dataset.c); return; }
  var lc = e.target.closest('.lc-h');
  if(lc){ openHeadEditor(+lc.dataset.c); return; }
  var seg = e.target.closest('th.seg');
  if(seg){
    openTimeHeadModal('seg', seg.dataset.segKey, seg.dataset.colDate, seg.dataset.defLabel);
    return;
  }
  var dh = e.target.closest('th.day-head');
  if(dh){
    openTimeHeadModal('col', 'col:' + dh.dataset.colKey, dh.dataset.colDate, dh.dataset.defLabel);
    return;
  }
});

/* ================= 工具条 ================= */
$('projName').addEventListener('input', function(){ data.name = $('projName').value; save(); renderTabs(); });
$('startIn').addEventListener('change', function(){ pushUndo(); data.start = $('startIn').value; render(); });
$('endIn').addEventListener('change', function(){ pushUndo(); data.end = $('endIn').value; render(); });
document.querySelectorAll('.seg-view button').forEach(function(btn){
  btn.addEventListener('click', function(){
    pushUndo();
    data.view = btn.dataset.view;
    render();
    toast(t('tViewSwitched',{v:({day:t('viewDay'),week:t('viewWeek'),month:t('viewMonth')})[data.view]}));
  });
});
$('presetWeek').addEventListener('click', function(){
  pushUndo();
  var ws = weekStart(today);
  data.start = fmt(ws); data.end = fmt(addDays(ws,6));
  render();
});
$('presetMonth').addEventListener('click', function(){
  pushUndo();
  data.start = fmt(new Date(today.getFullYear(), today.getMonth(), 1));
  data.end   = fmt(new Date(today.getFullYear(), today.getMonth()+1, 0));
  render();
});
$('presetQuarter').addEventListener('click', function(){
  pushUndo();
  var qm = Math.floor(today.getMonth()/3)*3;
  data.start = fmt(new Date(today.getFullYear(), qm, 1));
  data.end   = fmt(new Date(today.getFullYear(), qm+3, 0));
  render();
});
$('goToday').addEventListener('click', scrollToToday);
$('addTop').addEventListener('click', showItemModal);
$('resetBtn').addEventListener('click', function(){
  var hasColW = data.colWidths && Object.keys(data.colWidths).length > 0;
  var has = hasColW || data.items.some(function(it){
    if(it.hAdj) return true;
    return it.nodes.some(function(nd){ return nd.lblOff || nd.taskOff; });
  });
  if(!has){ toast(t('tNoManualPos')); return; }
  pushUndo();
  var n = 0;
  data.items.forEach(function(it){
    it.nodes.forEach(function(nd){
      if(nd.lblOff){ delete nd.lblOff; n++; }
      if(nd.taskOff){ delete nd.taskOff; n++; }
    });
    if(it.hAdj){ delete it.hAdj; n++; }
  });
  if(hasColW){
    n += Object.keys(data.colWidths).length;
    data.colWidths = {};
  }
  toast(t('tResetDone',{n:n}));
  save();
  render();
});
$('colScaleSel').addEventListener('change', function(){
  pushUndo();
  data.colScale = parseFloat(this.value) || 1;
  data.colWidths = {};
  save(); render();
  toast(t('tColScaleDone'));
});
/* ================= 连线样式 ================= */
function lineWidthOptions(sel, cur){
  sel.innerHTML = [1,2,3,4,5].map(function(w){
    return '<option value="'+w+'"'+(w===cur?' selected':'')+'>'+w+'px</option>';
  }).join('');
}
function lineStyleOptions(sel, cur){
  var map = (I18N[curLang] && I18N[curLang].lstyles) || I18N.zh.lstyles;
  sel.innerHTML = LINE_STYLES.map(function(s){
    return '<option value="'+s.id+'"'+(s.id===cur?' selected':'')+'>'+(map[s.id]||s.label)+'</option>';
  }).join('');
}
function lineArrowOptions(sel, cur){
  var map = (I18N[curLang] && I18N[curLang].arrows) || I18N.zh.arrows;
  sel.innerHTML = ARROW_SHAPES.map(function(s){
    return '<option value="'+s.id+'"'+(s.id===cur?' selected':'')+'>'+(map[s.id]||s.label)+'</option>';
  }).join('');
}
function openLineModal(){
  var L = lineOpts();
  $('lnColor').value = L.color;
  $('lnWidth').value = String(L.width);
  $('lnStyle').value = L.style;
  $('lnArrow').value = L.arrow;
  $('lineModal').classList.remove('hidden');
}
lineWidthOptions($('lnWidth'), LINE_DEFAULTS.width);
lineStyleOptions($('lnStyle'), LINE_DEFAULTS.style);
lineArrowOptions($('lnArrow'), LINE_DEFAULTS.arrow);
$('lineStyleBtn').addEventListener('click', openLineModal);
$('lnColorX').addEventListener('click', function(){ $('lnColor').value = LINE_DEFAULTS.color; });
$('lnCancel').addEventListener('click', function(){ hideModal('lineModal'); });
$('lnSave').addEventListener('click', function(){
  pushUndo();
  data.line = {
    color: $('lnColor').value || LINE_DEFAULTS.color,
    width: parseInt($('lnWidth').value, 10) || LINE_DEFAULTS.width,
    style: $('lnStyle').value || LINE_DEFAULTS.style,
    arrow: $('lnArrow').value || LINE_DEFAULTS.arrow
  };
  save(); hideModal('lineModal'); render();
  toast(t('tLineSaved'));
});
/* ================= 手动连线（交互 / 编辑） ================= */
var linkMode = false;
var linkStart = null;
var linkEditId = null;

function setLinkMode(on){
  linkMode = on;
  linkStart = null;
  clearLinkSource();
  clearLinkPreview();
  $('tableWrap').classList.toggle('link-mode', on);
  var b = $('linkBtn');
  if(b) b.classList.toggle('active', on);
}
function startDirectLink(iid, nid){
  if(!linkMode){
    setLinkMode(true);
  }
  handleLinkNodeClick(iid, nid);
}
function clearLinkPreview(){
  var ov = document.querySelector('svg.link-overlay');
  if(!ov) return;
  var prev = ov.querySelector('path.link-preview');
  if(prev) prev.remove();
}
function updateLinkPreview(clientX, clientY){
  if(!linkMode || !linkStart) return;
  var wrap = $('tableWrap');
  var ov = wrap && wrap.querySelector('svg.link-overlay');
  var table = wrap && wrap.querySelector('table.plan-table');
  if(!ov || !table) return;
  var ends = linkEnds();
  var A = ends[linkStart.iid + ':' + linkStart.nid];
  if(!A) return;
  var tableRect = table.getBoundingClientRect();
  var ax = A.x - tableRect.left, ay = A.y - tableRect.top;
  var bx = clientX - tableRect.left, by = clientY - tableRect.top;
  var prev = ov.querySelector('path.link-preview');
  if(!prev){
    prev = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    prev.setAttribute('class', 'link-preview');
    ov.appendChild(prev);
  }
  prev.setAttribute('d', 'M '+ax.toFixed(1)+' '+ay.toFixed(1)+' L '+bx.toFixed(1)+' '+by.toFixed(1));
}
function clearLinkSource(){
  document.querySelectorAll('.node.link-src').forEach(function(el){ el.classList.remove('link-src'); });
}
function markLinkSource(){
  clearLinkSource();
  if(!linkStart) return;
  var el = document.querySelector('.node[data-iid="'+linkStart.iid+'"][data-nid="'+linkStart.nid+'"]');
  if(el) el.classList.add('link-src');
}
function handleLinkNodeClick(iid, nid){
  if(!linkStart){
    linkStart = { iid:iid, nid:nid };
    markLinkSource();
    toast(t('tLinkStart'));
  } else if(linkStart.iid === iid && linkStart.nid === nid){
    linkStart = null; clearLinkSource(); clearLinkPreview();
    toast(t('tLinkStartCancel'));
  } else {
    var a = linkStart, b = { iid:iid, nid:nid };
    var dup = (data.links||[]).some(function(lk){
      return (lk.a.iid===a.iid && lk.a.nid===a.nid && lk.b.iid===b.iid && lk.b.nid===b.nid) ||
             (lk.a.iid===b.iid && lk.a.nid===b.nid && lk.b.iid===a.iid && lk.b.nid===a.nid);
    });
    if(dup){ toast(t('tLinkDup')); linkStart=null; clearLinkSource(); clearLinkPreview(); return; }
    pushUndo();
    data.links = data.links || [];
    var lk = { id:uid(), a:{iid:a.iid, nid:a.nid}, b:{iid:b.iid, nid:b.nid}, width:2, style:'solid' };
    data.links.push(lk);
    linkStart = null; clearLinkSource(); clearLinkPreview();
    setLinkMode(false);
    save(); render();
    openLinkModal(lk.id);
    toast(t('tLinkCreated'));
  }
}

/* ================= 时间标题栏编辑（调整年月 / 自定义显示标题） ================= */
var timeHeadState = null;
function refreshTimeHeadMonths(){
  var sel = $('thMonth');
  if(!sel) return;
  var cur = sel.value || '1';
  var opts = [];
  for(var m = 1; m <= 12; m++){
    var lbl = (curLang === 'en') ? MON_EN[m-1] : String(m);
    opts.push('<option value="'+m+'">'+lbl+'</option>');
  }
  sel.innerHTML = opts.join('');
  sel.value = cur;
}
refreshTimeHeadMonths();
function openTimeHeadModal(kind, labelKey, colDateStr, defLabel){
  var d = parse(colDateStr);
  var y = d.getFullYear(), m = d.getMonth() + 1;
  var isYearOnly = (kind === 'seg' && data.view === 'month');
  timeHeadState = { kind:kind, labelKey:labelKey, colDateStr:colDateStr, defLabel:defLabel, origY:y, origM:m, isYearOnly:isYearOnly };
  $('thModalTitle').textContent = (kind === 'seg') ? t('thSegTitle') : t('thColTitle');
  $('thYear').value = String(y);
  refreshTimeHeadMonths();
  $('thMonth').value = String(m);
  $('thMonth').classList.toggle('hidden', isYearOnly);
  $('thMonthUnit').classList.toggle('hidden', isYearOnly || curLang === 'en');
  $('thShiftNodes').checked = true;
  $('thCustomText').value = (data.timeLabels && data.timeLabels[labelKey]) || '';
  $('thCustomText').placeholder = t('thDefPh', { d: defLabel });
  $('timeHeadModal').classList.remove('hidden');
  $('thYear').focus();
  $('thYear').select();
}
$('thResetLabel').addEventListener('click', function(){
  $('thCustomText').value = '';
  $('thCustomText').focus();
});
$('thCancel').addEventListener('click', function(){ hideModal('timeHeadModal'); });
$('thSave').addEventListener('click', function(){
  if(!timeHeadState) return;
  var st = timeHeadState;
  var newY = parseInt($('thYear').value, 10);
  var newM = st.isYearOnly ? st.origM : parseInt($('thMonth').value, 10);
  if(isNaN(newY) || newY < 2000 || newY > 2100){ toast(t('tInvalidYear')); return; }
  if(isNaN(newM) || newM < 1 || newM > 12){ toast(t('tInvalidMonth')); return; }

  var deltaMonths = (newY - st.origY) * 12 + (newM - st.origM);
  var customTxt = $('thCustomText').value.trim();
  var oldCustom = (data.timeLabels && data.timeLabels[st.labelKey]) || '';
  if(deltaMonths === 0 && customTxt === oldCustom){
    hideModal('timeHeadModal');
    return;
  }

  pushUndo();
  data.timeLabels = data.timeLabels || {};

  /* 1. 若用户修改了年月，按月安全平移时间轴与节点（以及相关列宽键） */
  var targetLabelKey = st.labelKey;
  if(deltaMonths !== 0){
    data.start = addMonthsSafe(data.start, deltaMonths);
    data.end   = addMonthsSafe(data.end, deltaMonths);
    if($('thShiftNodes').checked){
      data.items.forEach(function(it){
        it.nodes.forEach(function(n){
          n.date = addMonthsSafe(n.date, deltaMonths);
        });
      });
    }
    /* 同步迁移自定义列宽键，避免年月平移后丢失单列宽度 */
    if(data.colWidths){
      var nextCW = {};
      Object.keys(data.colWidths).forEach(function(k){
        if(k.indexOf('m:') === 0){
          var nd = addMonthsSafe(k.slice(2) + '-01', deltaMonths);
          nextCW['m:' + nd.slice(0, 7)] = data.colWidths[k];
        } else if(k.indexOf('d:') === 0){
          nextCW['d:' + addMonthsSafe(k.slice(2), deltaMonths)] = data.colWidths[k];
        } else if(k.indexOf('w:') === 0){
          var wd = weekStart(parse(addMonthsSafe(k.slice(2), deltaMonths)));
          nextCW['w:' + fmt(wd)] = data.colWidths[k];
        } else {
          nextCW[k] = data.colWidths[k];
        }
      });
      data.colWidths = nextCW;
    }
    /* 计算平移后的新标题键 */
    var shiftedDate = parse(addMonthsSafe(st.colDateStr, deltaMonths));
    var shiftedCol = {
      type: data.view,
      date: (data.view === 'week') ? weekStart(shiftedDate) :
            (data.view === 'month' ? new Date(shiftedDate.getFullYear(), shiftedDate.getMonth(), 1) : shiftedDate)
    };
    targetLabelKey = (st.kind === 'seg') ? segLabelKey(shiftedCol) : ('col:' + colKey(shiftedCol));
    if(targetLabelKey !== st.labelKey && data.timeLabels[st.labelKey]){
      delete data.timeLabels[st.labelKey];
    }
  }

  /* 2. 保存或清除自定义标题文本 */
  if(customTxt){
    data.timeLabels[targetLabelKey] = customTxt;
  } else {
    delete data.timeLabels[targetLabelKey];
  }

  hideModal('timeHeadModal');
  render();
  if(deltaMonths !== 0){
    var dir = deltaMonths > 0 ? t('tDirFwd') : t('tDirBack');
    toast(t('tShifted', { dir:dir, n:Math.abs(deltaMonths), sync: $('thShiftNodes').checked ? t('tSyncNote') : '' }));
  } else {
    toast(customTxt ? t('tTimeLabelSaved') : t('tTimeLabelReset'));
  }
});
function openLinkModal(id){
  var lk = (data.links||[]).find(function(x){ return x.id===id; });
  if(!lk) return;
  linkEditId = id;
  $('lkWidth').value = String(lk.width || 2);
  $('lkStyle').value = lk.style || 'solid';
  $('linkModal').classList.remove('hidden');
}
function closeLinkModal(){ $('linkModal').classList.add('hidden'); }
$('linkBtn').addEventListener('click', function(){ setLinkMode(!linkMode); });
lineWidthOptions($('lkWidth'), 2);
lineStyleOptions($('lkStyle'), 'solid');
$('lkCancel').addEventListener('click', closeLinkModal);
$('lkDelete').addEventListener('click', function(){
  if(!linkEditId) return;
  pushUndo();
  data.links = (data.links||[]).filter(function(x){ return x.id!==linkEditId; });
  closeLinkModal(); save(); render();
  toast(t('tLinkDeleted'));
});
$('lkSave').addEventListener('click', function(){
  if(!linkEditId) return;
  var lk = (data.links||[]).find(function(x){ return x.id===linkEditId; });
  if(!lk){ closeLinkModal(); return; }
  pushUndo();
  lk.width = parseInt($('lkWidth').value, 10) || 2;
  lk.style = $('lkStyle').value || 'solid';
  closeLinkModal(); save(); render();
  toast(t('tLinkUpdated'));
});
/* 点击已有连线 → 编辑（粗细 / 虚实 / 删除） */
var linkOverlay = document.querySelector('svg.link-overlay');
if(linkOverlay){
  linkOverlay.addEventListener('click', function(e){
    if(linkMode) return;
    var hit = e.target.closest ? e.target.closest('.link-hit') : null;
    if(hit){ e.stopPropagation(); openLinkModal(hit.getAttribute('data-id')); }
  });
}
/* ================= 撤销（撤回） ================= */
var undoStack = [];
var UNDO_MAX = 50;
function updateUndoBtn(){
  var b = $('undoBtn');
  if(b) b.disabled = undoStack.length === 0;
}
function snapshot(){ return deepClone(data); }
function commitUndo(snap){
  if(!snap) return;
  var last = undoStack[undoStack.length-1];
  if(last && JSON.stringify(last) === JSON.stringify(snap)) return;
  undoStack.push(snap);
  if(undoStack.length > UNDO_MAX) undoStack.shift();
  updateUndoBtn();
}
function pushUndo(){ commitUndo(snapshot()); }
function undo(){
  if(!undoStack.length){ toast(t('tNoUndo')); return; }
  data = undoStack.pop();
  normalizeData();
  render();
  updateUndoBtn();
  toast(t('tUndone'));
}
$('undoBtn').addEventListener('click', undo);
updateUndoBtn();
/* ================= 计划表标签页 ================= */
function renderTabs(){
  var box = $('tabList');
  if(!box) return;
  box.innerHTML = sheets.map(function(s, i){
    var name = s.name || '未命名计划';
    var close = sheets.length > 1 ? '<button type="button" class="tab-close" data-i="'+i+'" title="'+esc(t('tipTabClose'))+'">✕</button>' : '';
    return '<div class="tab'+(i===activeIndex?' active':'')+'" data-i="'+i+'" title="'+esc(name)+'">' +
           '<span class="tab-name">'+esc(name)+'</span>'+close+'</div>';
  }).join('');
}
function switchTab(i){
  if(i === activeIndex || i < 0 || i >= sheets.length) return;
  sheets[activeIndex] = data;
  activeIndex = i;
  data = sheets[activeIndex];
  undoStack = []; updateUndoBtn();
  normalizeData();
  render();
  renderTabs();
}
function addSheet(){
  sheets[activeIndex] = data;
  var s = emptyData();
  s.name = '未命名计划 ' + (sheets.length + 1);
  sheets.push(s);
  activeIndex = sheets.length - 1;
  data = s;
  undoStack = []; updateUndoBtn();
  normalizeData();
  render();
  renderTabs();
  toast(t('tNewSheet'));
}
function closeTab(i){
  if(sheets.length <= 1){ toast(t('tKeepOneSheet')); return; }
  if(i < 0 || i >= sheets.length) return;
  var s = sheets[i];
  if((s.items||[]).length && !confirm(t('cCloseTab',{name:s.name||'Untitled'}))) return;
  sheets.splice(i, 1);
  if(activeIndex === i) activeIndex = Math.min(i, sheets.length - 1);
  else if(activeIndex > i) activeIndex--;
  data = sheets[activeIndex];
  undoStack = []; updateUndoBtn();
  normalizeData();
  render();
  renderTabs();
}
$('tabList').addEventListener('click', function(e){
  var close = e.target.closest('.tab-close');
  if(close){ closeTab(+close.dataset.i); return; }
  var tab = e.target.closest('.tab');
  if(tab){ switchTab(+tab.dataset.i); }
});
$('tabAdd').addEventListener('click', addSheet);
$('sampleBtn').addEventListener('click', function(){
  if(confirm(t('cLoadSample'))){ pushUndo(); data = defaultData(); render(); }
});
$('clearBtn').addEventListener('click', function(){
  if(confirm(t('cClearAll'))){ pushUndo(); data = emptyData(); render(); }
});

function scrollToToday(){
  var t = document.querySelector('.today-col');
  if(t) t.scrollIntoView({ inline:'center', block:'nearest' });
}

/* ================= 导出 Markdown ================= */
function mdDate(s){ var p = s.split('-'); return p[1]+'-'+p[2]; }
function mdSafe(s){
  return String(s==null?'':s).replace(/\|/g,'｜').replace(/\n/g,' ').replace(/\r/g,'');
}
function b64encode(str){ return btoa(unescape(encodeURIComponent(str))); }
function b64decode(str){ return decodeURIComponent(escape(atob(str))); }
function buildMarkdown(){
  var L = [];
  var all = [];
  data.items.forEach(function(it){
    it.nodes.forEach(function(n){ all.push({ it:it, n:n }); });
  });
  all.sort(function(a,b){ return a.n.date < b.n.date ? -1 : 1; });
  var dates = Array.from(new Set(all.map(function(x){ return x.n.date; }))).sort();

  L.push('# 项目计划：'+data.name);
  L.push('');
  L.push('> 计划周期：'+data.start+' ~ '+data.end+'　（共 '+data.items.length+' 个事项、'+all.length+' 个时间节点）');
  L.push('');
  L.push('## 线性流程');
  L.push('');
  data.items.forEach(function(it){
    var ns = it.nodes.slice().sort(function(a,b){ return a.date < b.date ? -1 : 1; });
    if(ns.length === 0){
      L.push('**'+mdSafe(it.name)+'**：_（暂无节点）_');
      L.push('');
      return;
    }
    var chain = ns.map(function(n){ return mdDate(n.date)+' '+n.title; }).join(' → ');
    L.push('**'+mdSafe(it.name)+'**');
    L.push('');
    L.push('- '+chain);
    ns.forEach(function(n){
      if(n.tasks.length){
        L.push('  - '+mdDate(n.date)+' '+n.title+'：'+n.tasks.map(mdSafe).join(' → '));
      }
    });
    L.push('');
  });
  L.push('## 时间节点概览');
  L.push('');
  L.push('| 事项 | '+dates.map(function(d){ return '**'+mdDate(d)+'**'; }).join(' | ')+' |');
  L.push('| --- | '+dates.map(function(){ return ' --- '; }).join('| ')+'|');
  data.items.forEach(function(it){
    var cells = dates.map(function(d){
      var ns = it.nodes.filter(function(n){ return n.date===d; });
      return ns.length ? ns.map(function(n){
        return '● '+(n.title||'节点')+(n.tasks.length ? '（'+mdSafe(n.tasks.join('、'))+'）' : '');
      }).join('<br>') : '';
    });
    L.push('| '+mdSafe(it.name)+' | '+cells.join(' | ')+' |');
  });
  L.push('');
  L.push('## 节点任务清单');
  L.push('');
  if(all.length === 0){
    L.push('_暂未添加时间节点，在时间轴中点击空白处即可添加。_');
    L.push('');
  }
  all.forEach(function(x){
    L.push('### ● '+mdDate(x.n.date)+' '+x.n.title+'（事项：'+x.it.name+'）');
    if(x.n.tasks.length){
      x.n.tasks.forEach(function(t){ L.push('- [ ] '+t); });
    } else {
      L.push('_（暂无任务）_');
    }
    L.push('');
  });
  /* 反向优化：嵌入机器可读数据，保证「导入」能完整恢复计划 */
  L.push('');
  L.push('<!-- 项目计划编辑器导出数据（用于导入恢复，请勿修改） -->');
  L.push('<!-- PPQE:' + b64encode(JSON.stringify(data)) + ' -->');
  return L.join('\n');
}
function openExport(){
  $('exportOut').value = buildMarkdown();
  $('exportModal').classList.remove('hidden');
}
$('exportBtn').addEventListener('click', openExport);
$('exportClose').addEventListener('click', function(){ hideModal('exportModal'); });
$('helpBtn').addEventListener('click', function(){ $('helpModal').classList.remove('hidden'); });
$('helpClose').addEventListener('click', function(){ hideModal('helpModal'); });
$('copyBtn').addEventListener('click', function(){
  var ta = $('exportOut');
  ta.select();
  try{
    navigator.clipboard.writeText(ta.value);
    toast(t('tCopied'));
  }catch(e){
    document.execCommand('copy');
    toast(t('tCopiedCompat'));
  }
});
$('dlBtn').addEventListener('click', function(){
  var blob = new Blob([$('exportOut').value], { type:'text/markdown;charset=utf-8' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = (data.name || '项目计划') + '.md';
  a.click();
  URL.revokeObjectURL(a.href);
  toast(t('tDownloaded',{f:a.download}));
});

/* ================= 导出 Excel（SpreadsheetML，零依赖 .xls） ================= */
function xmlEsc(s){
  return String(s==null?'':s).replace(/[&<>"']/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c];
  });
}
function excelCell(style, value, mergeAcross){
  var merge = (mergeAcross > 0) ? ' ss:MergeAcross="'+mergeAcross+'"' : '';
  return '<Cell ss:StyleID="'+style+'"'+merge+'><Data ss:Type="String">'+xmlEsc(value)+'</Data></Cell>';
}
function excelRow(cells, height){
  var h = height ? ' ss:Height="'+height+'"' : '';
  return '<Row'+h+'>'+cells.join('')+'</Row>';
}
function leftColLabels(){
  return data.leftCols.map(function(c, i){ return c.label || ('列'+(i+1)); });
}
function itemLeftTexts(it){
  return data.leftCols.map(function(c, ci){
    var cell = (it.cells && it.cells[ci]) || {};
    return cell.text || (ci === 0 ? (it.name || '') : '');
  });
}
function buildExcel(){
  var E = [];
  E.push('<?xml version="1.0" encoding="UTF-8"?>');
  E.push('<?mso-application progid="Excel.Sheet"?>');
  E.push('<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">');
  E.push('<Styles>');
  E.push('<Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Center"/><Font ss:FontName="微软雅黑" ss:Size="11"/></Style>');
  E.push('<Style ss:ID="sTitle"><Font ss:Bold="1" ss:Size="14" ss:Color="#3A4A86"/></Style>');
  E.push('<Style ss:ID="sMeta"><Font ss:Color="#7C8496" ss:Size="10"/></Style>');
  E.push('<Style ss:ID="sHeader"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#4F6EF7" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center" ss:Vertical="Center"/></Style>');
  E.push('<Style ss:ID="sCell"><Alignment ss:Vertical="Center" ss:WrapText="1"/></Style>');
  E.push('</Styles>');

  var M = data.leftCols.length;
  var labels = leftColLabels();
  var leftW = data.leftCols.map(function(c){ return Math.max(10, Math.min(34, Math.round((c.w || 160) / 7))); });

  /* ---- Sheet 1：节点任务清单 ---- */
  var cols1 = M + 3;
  E.push('<Worksheet ss:Name="节点任务清单">');
  E.push('<Table>');
  data.leftCols.forEach(function(c, i){ E.push('<Column ss:Width="'+leftW[i]+'"/>'); });
  E.push('<Column ss:Width="12"/>');
  E.push('<Column ss:Width="26"/>');
  E.push('<Column ss:Width="44"/>');
  E.push(excelRow([excelCell('sTitle', '项目计划：'+data.name, cols1-1)], 28));
  E.push(excelRow([excelCell('sMeta', '计划周期：'+data.start+' ~ '+data.end, cols1-1)], 18));
  var hdr1 = labels.map(function(l){ return excelCell('sHeader', l); });
  hdr1.push(excelCell('sHeader', '日期'));
  hdr1.push(excelCell('sHeader', '节点名称'));
  hdr1.push(excelCell('sHeader', '节点任务'));
  E.push(excelRow(hdr1, 22));
  data.items.forEach(function(it){
    var left = itemLeftTexts(it);
    var nodes = it.nodes.slice().sort(function(a,b){ return a.date < b.date ? -1 : 1; });
    if(!nodes.length){
      var row = left.map(function(t){ return excelCell('sCell', t); });
      row.push(excelCell('sCell', ''), excelCell('sCell', '（暂无节点）'), excelCell('sCell', ''));
      E.push(excelRow(row));
    } else {
      nodes.forEach(function(n){
        var row = left.map(function(t){ return excelCell('sCell', t); });
        row.push(excelCell('sCell', n.date));
        row.push(excelCell('sCell', n.title || '未命名节点'));
        row.push(excelCell('sCell', (n.tasks || []).join('、')));
        E.push(excelRow(row));
      });
    }
  });
  E.push('</Table>');
  E.push('<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><Selected/></WorksheetOptions>');
  E.push('</Worksheet>');

  /* ---- Sheet 2：时间线概览 ---- */
  var allDates = [];
  data.items.forEach(function(it){ it.nodes.forEach(function(n){ allDates.push(n.date); }); });
  var dates = Array.from(new Set(allDates)).sort();
  var cols2 = M + dates.length;
  E.push('<Worksheet ss:Name="时间线概览">');
  E.push('<Table>');
  data.leftCols.forEach(function(c, i){ E.push('<Column ss:Width="'+leftW[i]+'"/>'); });
  dates.forEach(function(){ E.push('<Column ss:Width="13"/>'); });
  E.push(excelRow([excelCell('sTitle', '项目计划：'+data.name, cols2-1)], 28));
  E.push(excelRow([excelCell('sMeta', '计划周期：'+data.start+' ~ '+data.end, cols2-1)], 18));
  var hdr2 = labels.map(function(l){ return excelCell('sHeader', l); });
  dates.forEach(function(d){ hdr2.push(excelCell('sHeader', d)); });
  E.push(excelRow(hdr2, 22));
  data.items.forEach(function(it){
    var row = itemLeftTexts(it).map(function(t){ return excelCell('sCell', t); });
    dates.forEach(function(d){
      var ns = it.nodes.filter(function(n){ return n.date === d; });
      var txt = ns.map(function(n){
        return (n.title || '节点') + (n.tasks && n.tasks.length ? '（'+n.tasks.join('、')+'）' : '');
      }).join('；');
      row.push(excelCell('sCell', txt));
    });
    E.push(excelRow(row));
  });
  E.push('</Table>');
  E.push('<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"/>');
  E.push('</Worksheet>');

  E.push('</Workbook>');
  return E.join('\n');
}
function exportExcel(){
  var xml = buildExcel();
  var blob = new Blob(['\ufeff'+xml], { type:'application/vnd.ms-excel;charset=utf-8' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = (data.name || '项目计划') + '.xls';
  a.click();
  setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
  toast(t('tExcelExported',{f:a.download}));
}
$('excelBtn').addEventListener('click', exportExcel);

/* ================= 导出 PNG / PDF（Canvas 自绘，零依赖） ================= */
function roundRect(ctx, x, y, w, h, r){
  if(w <= 0 || h <= 0) return;
  r = Math.min(r, w/2, h/2);
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w, y, x+w, y+h, r);
  ctx.arcTo(x+w, y+h, x, y+h, r);
  ctx.arcTo(x, y+h, x, y, r);
  ctx.arcTo(x, y, x+w, y, r);
  ctx.closePath();
}
function truncateText(ctx, txt, maxW){
  if(ctx.measureText(txt).width <= maxW) return txt;
  var out = txt;
  while(out.length > 1 && ctx.measureText(out+'…').width > maxW) out = out.slice(0, -1);
  return out + '…';
}
/* 把当前时间线绘制为一张画布（含手动拖动偏移、自定义列宽与自定义时间标题），供 PNG / PDF 共用 */
function renderTimelineCanvas(){
  var cols = buildColumns(parse(data.start), parse(data.end), data.view);
  var N = cols.length;
  if(!N) return null;
  var colWs = cols.map(function(c){ return colWOf(c); });
  var colLefts = [], totalTimeW = 0;
  for(var ci0 = 0; ci0 < N; ci0++){
    colLefts.push(totalTimeW);
    totalTimeW += colWs[ci0];
  }
  var M = data.leftCols.length, loff = leftOffsets();
  var itemColW = leftTotalW(), pad = 12, headerH = 62;
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  var rows = data.items.map(function(it, ri){
    var nodes = it.nodes.slice().sort(function(a,b){ return a.date < b.date ? -1 : 1; });
    /* 只导出当前时间范围内的节点 */
    var vis = nodes.filter(function(n){ return n.date >= data.start && n.date <= data.end; });
    var lpad = vis.reduce(function(m,n){ return Math.max(m, Math.max(0, nodeLblH(n)-32)); }, 0);
    var contentH = vis.reduce(function(m,n){
      return Math.max(m, n.tasks.length ? CHIP_TOP + n.tasks.length*nodeTaskStep(n) + 14 : 0);
    }, BASE_H);
    return { it:it, ri:ri, nodes:vis, rowH: contentH + lpad + (it.hAdj||0), lpad: lpad };
  });
  if(rows.length === 0) return null;

  var W = itemColW + totalTimeW + pad*2;
  var H = pad + headerH + rows.reduce(function(s,r){ return s+r.rowH; }, 0) + pad;
  var scale = Math.min(2, Math.floor(9000/W), Math.floor(9000/H));
  scale = Math.max(1, scale);

  var canvas = document.createElement('canvas');
  canvas.width = Math.round(W*scale);
  canvas.height = Math.round(H*scale);
  var ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);
  ctx.textBaseline = 'middle';

  var centers = [];
  for(var i = 0; i < N; i++) centers.push(itemColW + pad + colLefts[i] + colWs[i]/2);

  function colOf(dateStr){ return colIdxOf(cols, dateStr); }
  function baseXOf(dateStr, colIdx){
    if(colIdx < 0 || colIdx >= N) colIdx = 0;
    var d = parse(dateStr);
    var cw = colWs[colIdx];
    var cl = itemColW + pad + colLefts[colIdx];
    if(data.view === 'day') return centers[colIdx];
    if(data.view === 'week'){
      var di = (d.getDay()+6)%7;
      return cl + cw*(di+0.5)/7;
    }
    var daysIn = new Date(d.getFullYear(), d.getMonth()+1, 0).getDate();
    return cl + cw*((d.getDate()-1)+0.5)/daysIn;
  }

  /* ---- 表头 ---- */
  var y = pad;
  ctx.font = '600 11px '+FONT;
  var i2 = 0;
  while(i2 < N){
    var key = colGroupKey(cols[i2]), j = i2, w = 0;
    while(j < N && colGroupKey(cols[j]) === key){ w += colWs[j]; j++; }
    var x0 = itemColW + pad + colLefts[i2];
    ctx.fillStyle = '#f2f4f8';
    ctx.fillRect(x0, y, w, 28);
    ctx.fillStyle = '#5a6274';
    ctx.textAlign = 'center';
    ctx.fillText(segLabelText(cols[i2]), x0+w/2, y+14);
    i2 = j;
  }
  var lx = 0;
  var hcCov = headerCoverage();
  for(var hci = 0; hci < M; hci++){
    if(hcCov[hci] !== hci) continue;
    var hcs = data.leftCols[hci].cs || 1;
    var hcw = 0, hk2; for(hk2 = hci; hk2 < hci + hcs; hk2++) hcw += data.leftCols[hk2].w;
    var hcol = data.leftCols[hci];
    var hf = hcol.fmt || {};
    var hS = hf.size || 12;
    ctx.fillStyle = '#f2f4f8';
    ctx.fillRect(lx, y, hcw, 28);
    ctx.fillStyle = hf.color || '#3f4a68';
    ctx.textAlign = 'center';
    ctx.font = (hf.italic?'italic ':'') + (hf.bold?'700':'600') + ' '+hS+'px '+FONT;
    ctx.fillText(truncateText(ctx, hcol.label || '', Math.max(20, hcw - 18)), lx + hcw/2, y+14);
    lx += hcw;
  }
  var y2 = pad + 28;
  ctx.font = '11px '+FONT;
  cols.forEach(function(c, idx){
    ctx.fillStyle = (c.dow===0 || c.dow===6) ? '#b3b9c6' : '#8a91a3';
    ctx.fillText(colLabelText(c), centers[idx], y2+17);
  });
  ctx.strokeStyle = '#e3e6ec';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(itemColW, y); ctx.lineTo(itemColW, y+headerH);
  ctx.moveTo(itemColW+pad, y2); ctx.lineTo(itemColW+pad+totalTimeW, y2);
  ctx.stroke();

  /* ---- 泳道 ---- */
  var rowTop = pad + headerH;
  var allPos = {};
  rows.forEach(function(r){
    var rh = r.rowH;
    var lpad = r.lpad;
    var coff = rowCoff(r.it, rh);
    /* 左侧网格（多列 + 合并，时间轴区域不受影响） */
    var cov = leftCoverage();
    for(var ci = 0; ci < M; ci++){
      var m = cov[r.ri+','+ci];
      if(m && !(m.r === r.ri && m.c === ci)) continue;
      var rs = m ? m.rs : 1, cs = m ? m.cs : 1;
      var cw = 0, ck; for(ck = ci; ck < ci+cs; ck++) cw += data.leftCols[ck].w;
      var ch = 0; for(ck = 0; ck < rs && r.ri + ck < rows.length; ck++) ch += rows[r.ri + ck].rowH;
      var cell = leftCell(r.it, ci);
      var cText = cell.text || (ci === 0 ? (r.it.name || '') : '');
      var cX = loff[ci];
      /* 隔行底色 */
      if(r.ri % 2 === 1){
        ctx.fillStyle = '#f8f9fd';
        ctx.fillRect(cX, rowTop, cw, ch);
      }
      /* 边框：右 + 底（按跨度） */
      ctx.strokeStyle = '#e3e6ec';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cX + cw, rowTop); ctx.lineTo(cX + cw, rowTop + ch);
      ctx.moveTo(cX, rowTop + ch); ctx.lineTo(cX + cw, rowTop + ch);
      ctx.stroke();
      /* 文本（跨行合并垂直居中） */
      var cellFmt = cell.fmt || {};
      var cellS = cellFmt.size || 14;
      var txtY = rs > 1 ? rowTop + ch/2 : rowTop + 10;
      ctx.textAlign = 'left';
      ctx.font = (cellFmt.italic?'italic ':'') + (cellFmt.bold?'700':'600') + ' '+cellS+'px '+FONT;
      ctx.fillStyle = cellFmt.color || '#252b3b';
      ctx.fillText(truncateText(ctx, cText || '', Math.max(20, cw - 24)), cX + 12, txtY);
      if(ci === 0){
        /* 合并后第 0 列跨行时，节点/任务数汇总所有被合并行 */
        var mNodes = r.nodes.length, mTasks = r.nodes.reduce(function(s,n){ return s+n.tasks.length; },0);
        if(m && m.rs > 1){
          mNodes = 0; mTasks = 0;
          for(var mr = m.r; mr < m.r + m.rs && mr < rows.length; mr++){
            mNodes += rows[mr].nodes.length;
            rows[mr].nodes.forEach(function(n){ mTasks += n.tasks.length; });
          }
        }
        ctx.fillStyle = '#8a91a3';
        ctx.font = '10px '+FONT;
        ctx.fillText(t('metaFmt', { n:mNodes, t:mTasks }), cX + 12, rs > 1 ? rowTop + ch/2 + 14 : rowTop + 30);
      }
    }
    /* 时间轴区域：隔行底色 + 左边界 + 行底边界 */
    if(r.ri % 2 === 1){
      ctx.fillStyle = '#f8f9fd';
      ctx.fillRect(itemColW + pad, rowTop, totalTimeW, rh);
    }
    ctx.strokeStyle = '#e3e6ec';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(itemColW, rowTop); ctx.lineTo(itemColW, rowTop+rh);
    ctx.moveTo(itemColW, rowTop+rh); ctx.lineTo(W, rowTop+rh);
    ctx.stroke();
    /* 列分隔线 */
    ctx.strokeStyle = '#eceef3';
    for(var gi = 1; gi < N; gi++){
      var gx = itemColW + pad + colLefts[gi];
      ctx.beginPath();
      ctx.moveTo(gx, rowTop); ctx.lineTo(gx, rowTop+rh);
      ctx.stroke();
    }
    /* 虚线轨道 */
    ctx.save();
    ctx.setLineDash([5,4]);
    ctx.strokeStyle = '#d9dde6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(itemColW+pad, rowTop+38+lpad+coff); ctx.lineTo(W-pad, rowTop+38+lpad+coff);
    ctx.stroke();
    ctx.restore();

    /* 同日节点偏移（按节点分组） */
    var offMap = {};
    var byD = {};
    r.nodes.forEach(function(n){ (byD[n.date] = byD[n.date] || []).push(n.id); });
    Object.keys(byD).forEach(function(date){
      var nids = byD[date];
      var ci2 = colOf(date);
      var cw2 = (ci2 >= 0 && colWs[ci2]) ? colWs[ci2] : 120;
      nids.forEach(function(nid, k){
        offMap[nid] = nids.length > 1 ? (k-(nids.length-1)/2)*Math.min(cw2*0.12, 18) : 0;
      });
    });
    var pos = {};
    r.nodes.forEach(function(n){
      pos[n.id] = { x: baseXOf(n.date, colOf(n.date)) + (offMap[n.id]||0), y: rowTop+39+lpad+coff };
      allPos[n.id] = { x: pos[n.id].x, y: pos[n.id].y, size: nodeSize(n) };
    });

    /* 节点间连接线 + 箭头（颜色 / 粗细 / 虚实 / 箭头形状可自定义） */
    var L = lineOpts();
    var sorted = r.nodes.slice().sort(function(a,b){ return a.date < b.date ? -1 : 1; });
    ctx.save();
    ctx.strokeStyle = L.color;
    ctx.lineWidth = L.width;
    var segDash = L.style === 'dashed' ? [7,5] : (L.style === 'dotted' ? [2,4] : []);
    for(var li = 1; li < sorted.length; li++){
      var p1 = pos[sorted[li-1].id], p2 = pos[sorted[li].id];
      ctx.setLineDash(segDash);
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      if(L.arrow !== 'none'){
        ctx.setLineDash([]);
        drawArrowHead(ctx, p1.x, p1.y, p2.x, p2.y, L.arrow, L.color, L.width);
      }
    }
    ctx.restore();
    if(sorted.length){
      var lx = pos[sorted[sorted.length-1].id].x;
      var tx = Math.min(W-pad-4, lx+36);
      ctx.save();
      ctx.setLineDash([5,4]);
      ctx.strokeStyle = '#b9c4e8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(lx, rowTop+39+lpad+coff);
      ctx.lineTo(tx, rowTop+39+lpad+coff);
      ctx.stroke();
      ctx.restore();
    }

    /* 节点：标签 + 圆点 + 任务（含格式与拖动偏移，宽度不再截断） */
    var cap = 1e9;
    r.nodes.forEach(function(n){
      var p = pos[n.id];
      var d = parse(n.date);
      var F = n.fmt || {};
      var S = F.size || 11;
      var lblOff = (n.lblOff || {x:0, y:0});
      /* 标签（含手动拖动偏移） */
      ctx.font = (F.italic?'italic ':'') + (F.bold?'700':'600') + ' '+S+'px '+FONT;
      var tTxt = truncateText(ctx, (n.title||'未命名'), cap-14);
      var tW = ctx.measureText(tTxt).width;
      ctx.font = (F.italic?'italic ':'') + (F.bold?'700':'400') + ' '+Math.max(8,S-1)+'px '+FONT;
      var dTxt = (d.getMonth()+1)+'/'+d.getDate();
      var dW = ctx.measureText(dTxt).width;
      var lblW = Math.min(Math.max(tW, dW) + 14, cap);
      var lblH = nodeLblH(n);
      var lblX = p.x + lblOff.x - lblW/2, lblY = rowTop + coff + lblOff.y;
      /* 标签与圆点连接线 */
      ctx.strokeStyle = '#b9c4e8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - nodeSize(n)/2); ctx.lineTo(p.x + lblOff.x, lblY+lblH);
      ctx.stroke();
      roundRect(ctx, lblX, lblY, lblW, lblH, 6);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.strokeStyle = '#e3e6ec';
      ctx.stroke();
      ctx.textAlign = 'center';
      ctx.font = (F.italic?'italic ':'') + (F.bold?'700':'600') + ' '+S+'px '+FONT;
      ctx.fillStyle = F.color || '#3c4f9a';
      ctx.fillText(tTxt, p.x + lblOff.x, lblY + 2 + S*1.25/2);
      ctx.font = (F.italic?'italic ':'') + (F.bold?'700':'400') + ' '+Math.max(8,S-1)+'px '+FONT;
      ctx.fillStyle = F.color || '#8a91a3';
      ctx.fillText(dTxt, p.x + lblOff.x, lblY + 2 + S*1.25 + (S-1)*1.25/2);
      /* 节点图标（保持日期对齐，不随拖动；形状/颜色/大小可自定义） */
      drawNodeShape(ctx, p.x, p.y, nodeShape(n), nodeColor(n), nodeSize(n));
      /* 任务（含手动拖动偏移） */
      var step = nodeTaskStep(n);
      n.tasks.forEach(function(t, tk){
        var TF = (n.tFmt && n.tFmt[tk]) || {};
        var TS = TF.size || 11;
        var toff = (n.taskOff && n.taskOff[tk]) || {x:0, y:0};
        ctx.font = (TF.italic?'italic ':'') + (TF.bold?'700':'400') + ' '+TS+'px '+FONT;
        var tTxt2 = truncateText(ctx, t, cap-24);
        var cW = Math.min(ctx.measureText(tTxt2).width + 24, cap);
        var cH = Math.max(20, Math.round(TS*1.6 + 4));
        var cX = p.x + toff.x - cW/2;
        var cTop = rowTop + CHIP_TOP + tk*step + lpad + coff + toff.y;
        /* 圆点→任务竖线 + 横向 */
        ctx.strokeStyle = '#b9c4e8';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y + nodeSize(n)/2); ctx.lineTo(p.x, cTop+2); ctx.lineTo(p.x + toff.x, cTop+2);
        ctx.stroke();
        if(tk > 0){
          var pOff = (n.taskOff && n.taskOff[tk-1]) || {x:0, y:0};
          var cTopPrev = rowTop + CHIP_TOP + (tk-1)*step + lpad + coff + pOff.y;
          ctx.beginPath();
          ctx.moveTo(p.x + pOff.x, cTopPrev + cH);
          ctx.lineTo(p.x + pOff.x, cTop - 1);
          ctx.stroke();
        }
        roundRect(ctx, cX, cTop, cW, cH, cH/2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.strokeStyle = '#e3e6ec';
        ctx.stroke();
        ctx.textAlign = 'left';
        ctx.font = (TF.italic?'italic ':'') + (TF.bold?'700':'400') + ' '+TS+'px '+FONT;
        var midY = cTop + Math.round(cH/2);
        ctx.fillStyle = TF.color || '#4f6ef7';
        ctx.fillText('•', cX+8, midY);
        ctx.fillStyle = TF.color || '#20242e';
        ctx.fillText(tTxt2, cX+18, midY);
      });
    });
    rowTop += rh;
  });

  /* ---- 手动连线（节点图标 ↔ 节点图标，可跨行） ---- */
  (data.links||[]).forEach(function(lk){
    var A = allPos[(lk.a && lk.a.nid)], B = allPos[(lk.b && lk.b.nid)];
    if(!A || !B) return;
    var dx = B.x - A.x, dy = B.y - A.y;
    var len = Math.sqrt(dx*dx + dy*dy) || 1;
    var ux = dx/len, uy = dy/len;
    var x1 = A.x + ux*(A.size/2), y1 = A.y + uy*(A.size/2);
    var x2 = B.x - ux*(B.size/2), y2 = B.y - uy*(B.size/2);
    ctx.save();
    ctx.strokeStyle = MANUAL_LINK_COLOR;
    ctx.lineWidth = lk.width || 2;
    ctx.lineCap = 'round';
    ctx.setLineDash(lk.style === 'dashed' ? [7,5] : (lk.style === 'dotted' ? [2,4] : []));
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  });

  return { canvas: canvas, W: Math.round(W*scale), H: Math.round(H*scale), logW: W, logH: H };
}

function exportPNG(){
  var r = renderTimelineCanvas();
  if(!r){ toast(t('tNoExport')); return; }
  var a = document.createElement('a');
  r.canvas.toBlob(function(blob){
    a.href = URL.createObjectURL(blob);
    a.download = (data.name || '项目计划') + '.png';
    a.click();
    setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
    toast(t('tPngExported'));
  }, 'image/png');
}

/* 零依赖最小 PDF：把时间线位图以 JPEG 嵌入单页 PDF，直接下载 */
function exportPDF(){
  var r = renderTimelineCanvas();
  if(!r){ toast(t('tNoExport')); return; }
  r.canvas.toBlob(function(blob){
    if(!blob){ toast(t('tPdfFail')); return; }
    blob.arrayBuffer().then(function(buf){
      try{
        var img = new Uint8Array(buf);
        var enc = new TextEncoder();
        var parts = [];
        var size = 0;
        function addText(s){ var b = enc.encode(s); parts.push(b); size += b.length; }
        function addBin(b){ parts.push(b); size += b.length; }

        var pageW = Math.round(r.logW), pageH = Math.round(r.logH);
        var imgW = r.W, imgH = r.H;               /* 实际像素（含 2 倍清晰度） */
        var content = 'q '+pageW+' 0 0 '+pageH+' 0 0 cm /Im0 Do Q';

        addText('%PDF-1.4\n');
        var offsets = [];
        var objDefs = [
          '<< /Type /Catalog /Pages 2 0 R >>',
          '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
          '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+pageW+' '+pageH+'] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>',
          '<< /Type /XObject /Subtype /Image /Width '+imgW+' /Height '+imgH+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+img.length+' >>',
          '<< /Length '+content.length+' >>'
        ];
        for(var i = 1; i <= 5; i++){
          offsets.push(size);
          addText(i+' 0 obj\n'+objDefs[i-1]+'\n');
          if(i === 4){
            addText('stream\n'); addBin(img); addText('\nendstream\n');
          } else if(i === 5){
            addText('stream\n'+content+'\nendstream\n');
          }
          addText('endobj\n');
        }
        var xrefPos = size;
        addText('xref\n0 6\n0000000000 65535 f \n');
        offsets.forEach(function(o){
          addText(('0000000000'+o).slice(-10)+' 00000 n \n');
        });
        addText('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xrefPos+'\n%%EOF');

        var blob2 = new Blob(parts, { type:'application/pdf' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob2);
        a.download = (data.name || '项目计划') + '.pdf';
        a.click();
        setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
        toast(t('tPdfExported'));
      }catch(e){
        toast(t('tPdfFail'));
      }
    }).catch(function(){ toast(t('tPdfFail')); });
  }, 'image/jpeg', 0.93);
}
$('pngBtn').addEventListener('click', exportPNG);
$('pdfBtn').addEventListener('click', exportPDF);
$('printBtn').addEventListener('click', function(){
  hideModal('exportModal');
  setTimeout(function(){ window.print(); }, 50);
});

/* ================= 计划保存 / 计划库 ================= */
var PLANS_KEY = 'projectPlanQuickEditor.plans';
function loadPlans(){
  try{
    var raw = localStorage.getItem(PLANS_KEY);
    if(raw){ var arr = JSON.parse(raw); if(Array.isArray(arr)) return arr; }
  }catch(e){}
  return [];
}
function savePlans(plans){
  try{ localStorage.setItem(PLANS_KEY, JSON.stringify(plans)); }
  catch(e){ toast(t('tSaveFull')); }
}
function deepClone(o){ return JSON.parse(JSON.stringify(o)); }
function nowStamp(){
  var n = new Date();
  return n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate())+' '+pad(n.getHours())+':'+pad(n.getMinutes());
}
function countPlan(d){
  var items = (d.items||[]).length, nodes = 0, tasks = 0;
  (d.items||[]).forEach(function(it){
    nodes += (it.nodes||[]).length;
    (it.nodes||[]).forEach(function(n){ tasks += (n.tasks||[]).length; });
  });
  return { items:items, nodes:nodes, tasks:tasks };
}
function savePlanSnapshot(name){
  name = (name || '未命名计划').trim() || '未命名计划';
  var plans = loadPlans();
  var stamp = nowStamp();
  var existing = plans.find(function(p){ return p.name === name; });
  if(existing){ existing.data = deepClone(data); existing.savedAt = stamp; }
  else { plans.unshift({ id:uid(), name:name, savedAt:stamp, data:deepClone(data) }); }
  savePlans(plans);
  return name;
}
function renderPlanList(){
  var plans = loadPlans();
  var box = $('planList');
  $('planCount').textContent = plans.length ? t('planCountFmt', { n:plans.length }) : '';
  if(!plans.length){
    box.innerHTML = '<div class="pc-empty">'+esc(t('planEmpty'))+'</div>';
    return;
  }
  box.innerHTML = plans.map(function(p, i){
    var c = countPlan(p.data);
    return '<div class="plan-card">' +
      '<div class="pc-top"><span class="pc-name" title="'+esc(p.name)+'">'+esc(p.name)+'</span>' +
      '<span class="pc-time">'+esc(p.savedAt)+'</span></div>' +
      '<div class="pc-meta">'+esc(t('planMetaFmt', { i:c.items, n:c.nodes, t:c.tasks }))+'</div>' +
      '<div class="pc-actions">' +
      '<button type="button" class="btn mini" data-act="load" data-i="'+i+'">'+esc(t('loadBtn'))+'</button>' +
      '<button type="button" class="btn mini danger" data-act="del" data-i="'+i+'">'+esc(t('delBtn'))+'</button>' +
      '</div></div>';
  }).join('');
}
function openPlans(){
  $('planSaveName').value = data.name || '';
  renderPlanList();
  $('plansModal').classList.remove('hidden');
  $('planSaveName').focus();
}
$('savePlanBtn').addEventListener('click', function(){
  var name = (data.name || '未命名项目').trim() || '未命名项目';
  savePlanSnapshot(name);
  toast(t('tPlanSavedLib',{name:name}));
});
$('plansBtn').addEventListener('click', openPlans);
$('plansClose').addEventListener('click', function(){ hideModal('plansModal'); });
$('planSaveBtn').addEventListener('click', function(){
  var name = $('planSaveName').value.trim() || '未命名计划';
  var plans = loadPlans();
  if(plans.some(function(p){ return p.name === name; })){
    if(!confirm(t('cOverwritePlan',{name:name}))) return;
  }
  savePlanSnapshot(name);
  renderPlanList();
  toast(t('tPlanSaved',{name:name}));
});
$('planList').addEventListener('click', function(e){
  var btn = e.target.closest('button[data-act]');
  if(!btn) return;
  var plans = loadPlans();
  var p = plans[+btn.dataset.i];
  if(!p) return;
  if(btn.dataset.act === 'load'){
    if(!confirm(t('cLoadPlan',{name:p.name}))) return;
    pushUndo();
    data = deepClone(p.data);
    normalizeData();
    render();
    hideModal('plansModal');
    toast(t('tPlanLoaded',{name:p.name}));
  } else if(btn.dataset.act === 'del'){
    if(!confirm(t('cDelPlan',{name:p.name}))) return;
    plans.splice(+btn.dataset.i, 1);
    savePlans(plans);
    renderPlanList();
    toast(t('tPlanDeleted',{name:p.name}));
  }
});

/* ================= 预览模式（只读画板） ================= */
var pvScale = 1, pvX = 0, pvY = 0, pvDrag = null;

function applyPreviewTransform(){
  $('previewImg').style.transform = 'translate('+pvX+'px,'+pvY+'px) scale('+pvScale+')';
  $('pvZoomLabel').textContent = Math.round(pvScale*100) + '%';
}
function previewImgSize(){
  var img = $('previewImg');
  return { w: img.naturalWidth || parseFloat(img.style.width) || 1,
           h: img.naturalHeight || parseFloat(img.style.height) || 1 };
}
function fitPreview(){
  var stage = $('previewStage');
  var sz = previewImgSize();
  var sw = stage.clientWidth, sh = stage.clientHeight;
  pvScale = Math.min(sw/sz.w, sh/sz.h, 1);
  pvScale = Math.max(0.1, pvScale * 0.95);
  pvX = (sw - sz.w*pvScale)/2;
  pvY = (sh - sz.h*pvScale)/2;
  applyPreviewTransform();
}
function zoomPreview(factor){
  var stage = $('previewStage');
  var sz = previewImgSize();
  var cx = stage.clientWidth/2, cy = stage.clientHeight/2;
  var old = pvScale;
  var ns = Math.max(0.1, Math.min(6, old * factor));
  var wx = (cx - pvX)/old, wy = (cy - pvY)/old;
  pvX = cx - wx*ns;
  pvY = cy - wy*ns;
  pvScale = ns;
  applyPreviewTransform();
}
function openPreview(){
  var r = renderTimelineCanvas();
  if(!r){ toast(t('tNoPreview')); return; }
  var img = $('previewImg');
  img.src = r.canvas.toDataURL('image/png');
  img.style.width = r.W + 'px';
  img.style.height = r.H + 'px';
  $('pvTitle').textContent = t('pvTitleFmt',{name:data.name||t('appTitle')});
  $('previewModal').classList.remove('hidden');
  requestAnimationFrame(fitPreview);
}
$('previewBtn').addEventListener('click', openPreview);
$('pvClose').addEventListener('click', function(){
  $('previewModal').classList.add('hidden');
  pvDrag = null; $('previewStage').classList.remove('dragging');
});
$('pvZoomIn').addEventListener('click', function(){ zoomPreview(1.25); });
$('pvZoomOut').addEventListener('click', function(){ zoomPreview(1/1.25); });
$('pvFit').addEventListener('click', fitPreview);
$('previewStage').addEventListener('pointerdown', function(e){
  pvDrag = { x:e.clientX, y:e.clientY, ox:pvX, oy:pvY };
  $('previewStage').classList.add('dragging');
  if($('previewStage').setPointerCapture) $('previewStage').setPointerCapture(e.pointerId);
});
document.addEventListener('pointermove', function(e){
  if(!pvDrag) return;
  pvX = pvDrag.ox + (e.clientX - pvDrag.x);
  pvY = pvDrag.oy + (e.clientY - pvDrag.y);
  applyPreviewTransform();
});
document.addEventListener('pointerup', function(){
  if(pvDrag){ pvDrag = null; $('previewStage').classList.remove('dragging'); }
});
document.addEventListener('pointercancel', function(){
  if(pvDrag){ pvDrag = null; $('previewStage').classList.remove('dragging'); }
});
document.addEventListener('keydown', function(e){
  if(e.key === 'Escape'){
    $('previewModal').classList.add('hidden');
    pvDrag = null; $('previewStage').classList.remove('dragging');
  }
});

/* ================= 导入计划（.md） ================= */
function importPlanText(text, filename){
  var m = text.match(/<!-- PPQE:([A-Za-z0-9+/=]+) -->/);
  if(!m){
    toast(t('tImportBad'));
    return false;
  }
  var imported;
  try{
    imported = JSON.parse(b64decode(m[1]));
  }catch(e){
    toast(t('tImportErr'));
    return false;
  }
  if(!imported || typeof imported !== 'object' || !Array.isArray(imported.items)){
    toast(t('tImportEmpty'));
    return false;
  }
  sheets[activeIndex] = data;
  if(!imported.name) imported.name = (filename || '导入计划').replace(/\.md$/i, '');
  sheets.push(imported);
  activeIndex = sheets.length - 1;
  data = imported;
  undoStack = []; updateUndoBtn();
  normalizeData();
  render();
  toast(t('tImported',{name:data.name}));
  return true;
}
$('importBtn').addEventListener('click', function(){ $('importModal').classList.remove('hidden'); });
$('importCancel').addEventListener('click', function(){ hideModal('importModal'); });
$('importFile').addEventListener('change', function(){
  var f = this.files && this.files[0];
  if(!f) return;
  var reader = new FileReader();
  reader.onload = function(){
    if(importPlanText(String(reader.result), f.name)) hideModal('importModal');
  };
  reader.onerror = function(){ toast(t('tReadFail')); };
  reader.readAsText(f);
  this.value = '';
});

/* ================= 通用 ================= */
var toastTimer;
function toast(msg){
  var t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 2200);
}
document.querySelectorAll('.modal-mask').forEach(function(m){
  m.addEventListener('click', function(e){
    if(e.target === m && !document.body.classList.contains('modal-dragging')) m.classList.add('hidden');
  });
});
document.addEventListener('keydown', function(e){
  if(e.key === 'Escape'){
    document.querySelectorAll('.modal-mask:not(.hidden)').forEach(function(m){ m.classList.add('hidden'); });
    if(linkMode){ setLinkMode(false); toast(t('tLinkExit')); }
  }
});
$('timeHeadModal').addEventListener('keydown', function(e){
  if(e.key === 'Enter'){ e.preventDefault(); $('thSave').click(); }
});
window.addEventListener('resize', function(){ renderAll(); placeGrip(); });

/* ================= 更多菜单（收纳低频操作） ================= */
(function(){
  var wrap = $('moreWrap'), btn = $('moreBtn'), menu = $('moreMenu');
  if(!wrap || !btn || !menu) return;
  function closeMenu(){
    menu.classList.add('hidden');
    wrap.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
  }
  btn.addEventListener('click', function(e){
    e.stopPropagation();
    var willOpen = menu.classList.contains('hidden');
    menu.classList.toggle('hidden', !willOpen);
    wrap.classList.toggle('open', willOpen);
    btn.setAttribute('aria-expanded', String(willOpen));
  });
  menu.addEventListener('click', function(e){
    if(e.target.closest('button')) closeMenu();
  });
  document.addEventListener('click', function(e){
    if(!wrap.contains(e.target)) closeMenu();
  });
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeMenu();
  });
})();

/* ================= 显示语言切换（中 / EN） ================= */
function setElText(sel, txt){
  var el = typeof sel === 'string' ? document.querySelector(sel) : sel;
  if(el) el.textContent = txt;
}
function setElAttr(sel, attr, val){
  var el = typeof sel === 'string' ? document.querySelector(sel) : sel;
  if(el) el.setAttribute(attr, val);
}
function setFieldLabel(modalId, idx, mainTxt, tipTxt){
  var labels = document.querySelectorAll('#' + modalId + ' .field > label:not(.time-check)');
  var lb = labels[idx];
  if(!lb) return;
  lb.innerHTML = tipTxt ? (esc(mainTxt) + ' <span class="fmt-tip">' + esc(tipTxt) + '</span>') : esc(mainTxt);
}
function applyLanguage(lang, silent){
  curLang = (lang === 'en') ? 'en' : 'zh';
  try{ localStorage.setItem(LANG_KEY, curLang); }catch(e){}
  document.documentElement.lang = (curLang === 'en') ? 'en' : 'zh-CN';
  document.title = t('appTitle');

  /* 语言分段按钮状态 */
  document.querySelectorAll('#langSeg button').forEach(function(b){
    b.classList.toggle('active', b.dataset.lang === curLang);
  });

  /* 主菜单第一层 */
  setElText('.toolbar .brand-name', t('appTitle'));
  setElAttr('.toolbar .brand', 'title', t('appTitle') + ' v1.6 · Author: Yan Guangping');
  setElAttr('#projName', 'placeholder', t('projPh'));
  setElAttr('#projName', 'title', t('projTitle'));
  setElText('#plansBtn', t('plansBtn')); setElAttr('#plansBtn', 'title', t('plansTip'));
  setElText('#savePlanBtn', t('saveBtn')); setElAttr('#savePlanBtn', 'title', t('saveTip'));
  setElText('#previewBtn', t('previewBtn')); setElAttr('#previewBtn', 'title', t('previewTip'));
  setElText('#exportBtn', t('exportBtn'));
  setElAttr('#moreBtn', 'title', t('moreTip'));
  setElText('#importBtn', t('importMenu'));
  setElText('#sampleBtn', t('sampleMenu'));
  setElText('#helpBtn', t('helpMenu'));
  setElText('#clearBtn', t('clearMenu'));

  /* 主菜单第二层 */
  setElText('#addTop', t('addTop'));
  setElText('#undoBtn', t('undoBtn')); setElAttr('#undoBtn', 'title', t('undoTip'));
  setElAttr('#colScaleSel', 'title', t('colScaleTip'));
  var colOpts = $('colScaleSel') && $('colScaleSel').options;
  if(colOpts && colOpts.length >= 4){
    colOpts[0].textContent = t('colW_075');
    colOpts[1].textContent = t('colW_1');
    colOpts[2].textContent = t('colW_125');
    colOpts[3].textContent = t('colW_15');
  }
  setElText('#linkBtn', t('linkBtn')); setElAttr('#linkBtn', 'title', t('linkTip'));
  setElText('#lineStyleBtn', t('lineStyleBtn')); setElAttr('#lineStyleBtn', 'title', t('lineStyleTip'));
  setElText('#resetBtn', t('resetBtn')); setElAttr('#resetBtn', 'title', t('resetTip'));
  setElAttr('.range', 'title', t('rangeTip'));
  setElAttr('#startIn', 'title', t('startTip'));
  setElAttr('#endIn', 'title', t('endTip'));
  setElText('#presetWeek', t('presetWeek'));
  setElText('#presetMonth', t('presetMonth'));
  setElText('#presetQuarter', t('presetQuarter'));
  setElText('.seg-view button[data-view="day"]', t('viewDay'));
  setElText('.seg-view button[data-view="week"]', t('viewWeek'));
  setElText('.seg-view button[data-view="month"]', t('viewMonth'));
  setElAttr('#scrollL', 'title', t('scrollLTip'));
  setElAttr('#scrollR', 'title', t('scrollRTip'));
  setElText('#goToday', t('goToday')); setElAttr('#goToday', 'title', t('goTodayTip'));
  setElText('#fitBtn', t('fitBtn')); setElAttr('#fitBtn', 'title', t('fitTip'));
  setElText('#extendWeek', t('extWeek')); setElAttr('#extendWeek', 'title', t('extWeekTip'));
  setElText('#extendMonth', t('extMonth')); setElAttr('#extendMonth', 'title', t('extMonthTip'));

  /* 标签页 & 图例 & 拉长手柄 */
  setElText('#tabAdd', t('tabAdd')); setElAttr('#tabAdd', 'title', t('tabAddTip'));
  var lgs = document.querySelectorAll('.legend .lg');
  if(lgs.length >= 4){
    lgs[0].innerHTML = '<i class="lg-dot"></i>' + esc(t('lgDot'));
    lgs[1].innerHTML = '<i class="lg-line"></i>' + esc(t('lgLine'));
    lgs[2].innerHTML = '<i class="lg-chip"></i>' + esc(t('lgChip'));
    lgs[3].textContent = t('lgHint');
  }
  setElAttr('#stretchGrip', 'title', t('stretchTip'));

  /* 节点弹窗 */
  setFieldLabel('nodeModal', 0, t('nodeTitleLbl'));
  setElAttr('#ndTitle', 'placeholder', t('nodeTitlePh'));
  setElText('#nodeModal .fmt-bar .fmt-tip', t('lblFmtTip'));
  setFieldLabel('nodeModal', 1, t('dateLbl'));
  setFieldLabel('nodeModal', 2, t('nodeIconLbl'), t('nodeIconTip'));
  setFieldLabel('nodeModal', 3, t('nodeItemLbl'));
  setFieldLabel('nodeModal', 4, t('nodeTasksLbl'), t('nodeTasksTip'));
  setElText('#ndAddTask', t('nodeAddTask'));
  setElText('#ndDelete', t('nodeDel'));
  setElText('#ndCancel', t('cancelBtn'));
  setElText('#ndSave', t('saveBtn'));
  shapeOptions($('ndShape'), $('ndShape').value || 'circle');

  /* 单元格编辑弹窗 */
  setElText('#cellModal h3', t('cellTitle'));
  setFieldLabel('cellModal', 0, t('cellTextLbl'));
  setElAttr('#clText', 'placeholder', t('cellTextPh'));
  setFieldLabel('cellModal', 1, t('textFmtLbl'));
  setFieldLabel('cellModal', 2, t('cellMergeLbl'), t('cellMergeTip'));
  setElText('#clMergeU', t('mergeU')); setElText('#clMergeD', t('mergeD'));
  setElText('#clMergeL', t('mergeL')); setElText('#clMergeR', t('mergeR'));
  setElText('#clSplit', t('splitBtn'));
  setElText('#clCancel', t('cancelBtn')); setElText('#clSave', t('saveBtn'));

  /* 列标题弹窗 */
  setElText('#headModal h3', t('headTitle'));
  setFieldLabel('headModal', 0, t('headTextLbl'));
  setElAttr('#hdText', 'placeholder', t('headTextPh'));
  setFieldLabel('headModal', 1, t('textFmtLbl'));
  setFieldLabel('headModal', 2, t('headMergeLbl'), t('headMergeTip'));
  setElText('#hdMergeL', t('hdMergeL')); setElText('#hdMergeR', t('hdMergeR'));
  setElText('#hdSplit', t('splitBtn'));
  setElText('#hdCancel', t('cancelBtn')); setElText('#hdSave', t('saveBtn'));

  /* 时间标题弹窗 */
  setFieldLabel('timeHeadModal', 0, t('thYmLbl'), t('thYmTip'));
  setElText('#timeHeadModal .time-ym-row span:nth-of-type(1)', t('thYearUnit'));
  setElText('#thMonthUnit', t('thMonthUnit'));
  setElText('#thShiftLbl', t('thShiftLbl'));
  setFieldLabel('timeHeadModal', 1, t('thCustomLbl'), t('thCustomTip'));
  setElText('#thResetLabel', t('thReset'));
  setElText('#thCancel', t('cancelBtn')); setElText('#thSave', t('applyBtn'));
  refreshTimeHeadMonths();

  /* 添加事项弹窗 */
  setElText('#itemModal h3', t('itemTitle'));
  setFieldLabel('itemModal', 0, t('itemNameLbl'));
  setElAttr('#itName', 'placeholder', t('itemNamePh'));
  setElText('#itCancel', t('cancelBtn')); setElText('#itSave', t('addBtn'));

  /* 导出弹窗 */
  setElText('#exportModal h3', t('exportTitle'));
  setElText('#exportModal p', t('exportDesc'));
  setElText('#pngBtn', t('pngBtn')); setElText('#pdfBtn', t('pdfBtn'));
  setElText('#printBtn', t('printBtn')); setElText('#dlBtn', t('dlBtn'));
  setElText('#excelBtn', t('excelBtn')); setElText('#copyBtn', t('copyBtn'));
  setElText('#exportClose', t('closeBtn'));

  /* 帮助弹窗 */
  setElText('#helpModalTitle', t('helpTitle'));
  if($('helpZh')) $('helpZh').classList.toggle('hidden', curLang === 'en');
  if($('helpEn')) $('helpEn').classList.toggle('hidden', curLang !== 'en');
  setElText('#helpClose', t('closeBtn'));

  /* 连线样式 & 手动连线弹窗 */
  setElText('#lineModal h3', t('lineTitle'));
  setFieldLabel('lineModal', 0, t('lnColorLbl'));
  setFieldLabel('lineModal', 1, t('lnWidthLbl'));
  setFieldLabel('lineModal', 2, t('lnStyleLbl'));
  setFieldLabel('lineModal', 3, t('lnArrowLbl'));
  setElText('#lnCancel', t('cancelBtn')); setElText('#lnSave', t('saveBtn'));
  lineStyleOptions($('lnStyle'), $('lnStyle').value || LINE_DEFAULTS.style);
  lineArrowOptions($('lnArrow'), $('lnArrow').value || LINE_DEFAULTS.arrow);

  setElText('#linkModal h3', t('linkTitle'));
  setFieldLabel('linkModal', 0, t('lnWidthLbl'));
  setFieldLabel('linkModal', 1, t('lnStyleLbl'));
  setElText('#lkDelete', t('lkDel'));
  setElText('#lkCancel', t('cancelBtn')); setElText('#lkSave', t('saveBtn'));
  lineStyleOptions($('lkStyle'), $('lkStyle').value || 'solid');

  /* 计划库 & 导入 & 预览 */
  setElText('#plansModal h3', t('plansTitle'));
  setFieldLabel('plansModal', 0, t('planSaveLbl'));
  setElAttr('#planSaveName', 'placeholder', t('planSavePh'));
  setElText('#planSaveBtn', t('saveBtn'));
  setElText('#plansModal .field p', t('planSaveDesc'));
  setElText('#plansModal .plan-list-head span:first-child', t('planListHead'));
  setElText('#plansClose', t('closeBtn'));

  setElText('#importModal h3', t('importTitle'));
  var impPs = document.querySelectorAll('#importModal p');
  if(impPs[0]) impPs[0].innerHTML = t('importWarn');
  setFieldLabel('importModal', 0, t('importFileLbl'));
  if(impPs[1]) impPs[1].textContent = t('importDesc');
  setElText('#importCancel', t('cancelBtn'));

  setElText('#pvClose', t('pvClose'));
  setElText('#pvTitle', t('pvTitleDef'));
  setElText('#pvFit', t('pvFit'));

  render();
  placeGrip();
  if(!silent){
    toast(curLang === 'en' ? 'Switched to English' : '已切换为简体中文');
  }
}
document.querySelectorAll('#langSeg button').forEach(function(b){
  b.addEventListener('click', function(){
    if(b.dataset.lang !== curLang) applyLanguage(b.dataset.lang);
  });
});

/* ================= 启动 ================= */
applyLanguage(curLang, true);
scrollToToday();
placeGrip();
